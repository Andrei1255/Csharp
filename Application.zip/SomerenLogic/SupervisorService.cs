﻿using SomerenDAL;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class SupervisorService
    {
        SupervisorDao supervisordb;

        public SupervisorService()
        {
            supervisordb = new SupervisorDao();
        }

        public List<Supervisor> GetSupervisorsInActivity(Supervisor supervisor)
        {
            List<Supervisor> supervisors = supervisordb.GetAllSupervisorsInActivity(supervisor);
            return supervisors;
        }

        public void AddSupervisor(Supervisor supervisor)
        {
            supervisordb.AddSupervisor(supervisor);
        }

        public void DeleteSupervisor(Supervisor supervisor)
        {
            supervisordb.DeleteSupervisor(supervisor);
        }

    }
}
