﻿using SomerenDAL;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class DrinkService
    {
        DrinkDao drinkdb;

        public DrinkService()
        {
            drinkdb = new DrinkDao();
        }

        public List<Drink> GetDrinks()
        {
            List<Drink> drinks = drinkdb.GetAllDrinks();
            return drinks;
        }


        public int GetSoldDrinksCount(DateTime startDate, DateTime endDate)
        {
            int drinks = drinkdb.GetAllSoldDrinks(startDate, endDate);
            return drinks;
        }

        public double GetSoldDrinksPrice(DateTime startDate, DateTime endDate)
        {
            double price = drinkdb.GetAllSoldDrinksPrice(startDate, endDate);
            return price;
        }

        public List<Drink> GetDrinksInStock()
        {
            List<Drink> drinks = drinkdb.GetAllDrinksInStock();
            return drinks;
        }


        public void UpdateDrinkName(Drink drink)
        {
            drinkdb.UpdateDrinkName(drink);
        }

        public void UpdateDrinkAmount(Drink drink)
        {
            drinkdb.UpdateDrinkAmount(drink);
        }

    }
}
