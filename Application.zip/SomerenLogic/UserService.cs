﻿using SomerenDAL;
using SomerenModel;
using SomerenPasswordEncryption;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class UserService
    {
        UserDAO userdb;

        public UserService()
        {
            userdb = new UserDAO();
        }

        public List<User> GetUsers()
        {
            List<User> users = userdb.GetUsers();
            return users;
        }

        public User GetUser(string userName)
        {
            User user = userdb.GetUser(userName);
            return user;
        }

        public string GetSecretQuestion(string userName)
        {
            return userdb.GetSecretQuestion(userName);
        }

        public string GetSecretAnswer(string userName)
        {
            return userdb.GetSecretAnswer(userName);
        }

        public void ChangePassword(string userName, string newPassword)
        {
            //PasswordEncryption.PasswordStorage passwordEncryption = new PasswordEncryption.PasswordStorage();

            string hashedPassword = PasswordEncryption.PasswordStorage.CreateHash(newPassword);

            userdb.ChangePassword(userName, hashedPassword);
        }

        public void ChangePassword(int userID, string newPassword)
        {
            string hashedPassword = PasswordEncryption.PasswordStorage.CreateHash(newPassword);

            userdb.ChangePassword(userID, hashedPassword);
        }

        public bool CheckSecretAnswer(string userName, string answer)
        {
            return userdb.CheckSecretAnswer(userName, answer);
        }

        public bool ComparePassword(string userName, string password)
        {
            string passwordInTheDB = userdb.GetPassword(userName);

            if (PasswordEncryption.PasswordStorage.VerifyPassword(password, passwordInTheDB))
                return true;

            return false;
        }

        public void AddUser(User user)
        {
            user.User_Password = PasswordEncryption.PasswordStorage.CreateHash(user.User_Password);
            userdb.AddUser(user);
        }

        public bool CompareLicenceKey(string licenceKey)
        {
            return userdb.CompareLicenceKey(licenceKey);
        }
    }
}
