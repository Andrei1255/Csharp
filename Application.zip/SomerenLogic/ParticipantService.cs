﻿using SomerenDAL;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class ParticipantService
    {
        ParticipantDao participantdb;

        public ParticipantService()
        {
            participantdb = new ParticipantDao();
        }

        public List<Participant> GetParticipants(int activityID)
        {
            List<Participant> participant = participantdb.GetAllParticipants(activityID);
            return participant;
        }

        public void AddParticipant(int participantId, int studentId, int activityId)
        {
            participantdb.AddParticipant(participantId, studentId, activityId);
        }

        public void RemoveParticipant(int participantId)
        {
            participantdb.RemoveParticipant(participantId);
        }
    }
}
