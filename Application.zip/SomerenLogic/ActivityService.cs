﻿using SomerenDAL;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenLogic
{
    public class ActivityService
    {
        ActivityDao activitydb;

        public ActivityService()
        {
            activitydb = new ActivityDao();
        }

        public List<Activity> GetActivities()
        {
            List<Activity> activities = activitydb.GetAllActivities();
            return activities;
        }
        public void AddActivity(Activity activity)
        {
            activitydb.AddActivity(activity);
        }
        public void RemoveActivity(Activity activity)
        {
            activitydb.RemoveActivity(activity);
        }
        public void ChangeActivityName(Activity activity)
        {
            activitydb.ChangeActivityName(activity);
        }
        public void ChangeActivityStartDateTime(Activity activity)
        {
            activitydb.ChangeActivityStartDateTime(activity);
        }
        public void ChangeActivityEndDateTime(Activity activity)
        {
            activitydb.ChangeActivityEndDateTime(activity);
        }
    }
}
