﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Participant
    {
        public int ParticipantId { get; set; }
        public int StudentId { get; set; }
        public int ActivityId { get; set; }
        public string ParticipantName { get; set; }
    }
}
