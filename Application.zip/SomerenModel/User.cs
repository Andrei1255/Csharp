﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class User
    {
        public int User_ID { get; set; }
        public string User_Name { get; set; }
        public string User_Password { get; set; }
        public string User_SecretQuestion { get; set; }
        public string User_SecretAnswer { get; set; }
        public string User_AdminStatus { get; set; }
    }
}
