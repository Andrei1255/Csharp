﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Drink
    {
        public int DrinkId { get; set; }

        public decimal DrinkPrice { get; set; }

        public string DrinkName { get; set; }

        public int Amount { get; set; }

        public bool DrinkAlcoholic { get; set; }

        public int TeacherId { get; set; }

        public int StudentId { get; set; }

        public override string ToString()
        {
            return $"ID: {DrinkId}, Name: {DrinkName}, Price: {DrinkPrice}, Amount: {Amount}";
        }
    }
}
