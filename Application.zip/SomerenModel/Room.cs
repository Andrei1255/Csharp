﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Room
    {
        private int id;
        private int capacity;
        public int Id { get { return id; } set { id = value; } }
        public int Number { get; set; } // RoomNumber, e.g. 206

        // number of beds, either 4,6,8,12 or 16
        public int Capacity
        {
            get { return capacity; }
            set
            {
                switch (value)
                {
                    case 4:
                    case 6:
                    case 8:
                    case 12:
                    case 16:
                        capacity = value;
                        break;
                    default:
                        throw new Exception($"Invalid room capacity ({value})!");
                }
            }
        }

        public bool Type { get; set; } // student = false, teacher = true
    }
}