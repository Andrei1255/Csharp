namespace SomerenUI
{
    partial class SomerenUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SomerenUI));
            this.imgDashboard = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dashboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dashboardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teachersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listOfActivitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activityParticipantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activitySupervisorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drinksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drinkSuppliesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cashRegisterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlDashboard = new System.Windows.Forms.Panel();
            this.lbl_Dashboard = new System.Windows.Forms.Label();
            this.pnlTeachers = new System.Windows.Forms.Panel();
            this.listViewTeachers = new System.Windows.Forms.ListView();
            this.teacherID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.teacherName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roomID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roompictureBox = new System.Windows.Forms.PictureBox();
            this.lbl_Teachers = new System.Windows.Forms.Label();
            this.pnlRooms = new System.Windows.Forms.Panel();
            this.listViewRooms = new System.Windows.Forms.ListView();
            this.RoomRoomID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roomNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roomCapacity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roomType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pnlDrinksCash = new System.Windows.Forms.Panel();
            this.lblTotalDrinksCash = new System.Windows.Forms.Label();
            this.TotalDrinksCash = new System.Windows.Forms.Label();
            this.btnBuy = new System.Windows.Forms.Button();
            this.checkedListBoxDrinks = new System.Windows.Forms.CheckedListBox();
            this.listViewDrinkStudents = new System.Windows.Forms.ListView();
            this.DrinkStudentID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkStudentName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbl_CashRegister = new System.Windows.Forms.Label();
            this.lbl_Students = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listViewStudents = new System.Windows.Forms.ListView();
            this.studentID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studentName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studentDOB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlStudents = new System.Windows.Forms.Panel();
            this.pnlDrinkSupplies = new System.Windows.Forms.Panel();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.idLabel = new System.Windows.Forms.Label();
            this.changeNameButton = new System.Windows.Forms.Button();
            this.newNameLabel = new System.Windows.Forms.Label();
            this.changeNameTextBox = new System.Windows.Forms.TextBox();
            this.amountLabel = new System.Windows.Forms.Label();
            this.changeAmountTextBox = new System.Windows.Forms.TextBox();
            this.updateAmountButton = new System.Windows.Forms.Button();
            this.listViewDrinkSupplies = new System.Windows.Forms.ListView();
            this.DrinkId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkAmountInStock = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DrinkSalesPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.drinkSuppliesPictureBox = new System.Windows.Forms.PictureBox();
            this.drinkSuppliesLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pnlReport = new System.Windows.Forms.Panel();
            this.txtNumberOfCustomers = new System.Windows.Forms.Label();
            this.txtTurnover = new System.Windows.Forms.Label();
            this.txtNumberOfSales = new System.Windows.Forms.Label();
            this.lbNumberOfCustomers = new System.Windows.Forms.Label();
            this.lbTurnover = new System.Windows.Forms.Label();
            this.lbNumberOfSales = new System.Windows.Forms.Label();
            this.buttonGenerate = new System.Windows.Forms.Button();
            this.monthCalendarStartDate = new System.Windows.Forms.MonthCalendar();
            this.listViewReport = new System.Windows.Forms.ListView();
            this.lblReport = new System.Windows.Forms.Label();
            this.pnlListOfActivities = new System.Windows.Forms.Panel();
            this.btnListActivityChangeEndDateTime = new System.Windows.Forms.Button();
            this.endDateTimePickerListActivityChange = new System.Windows.Forms.DateTimePicker();
            this.lblListActivityEndDateTimeChange = new System.Windows.Forms.Label();
            this.endDateTimePickerListActivity = new System.Windows.Forms.DateTimePicker();
            this.lblListActivityEndDateTime = new System.Windows.Forms.Label();
            this.lblDeviderLine1 = new System.Windows.Forms.Label();
            this.lblDeviderLine2 = new System.Windows.Forms.Label();
            this.btnListActivityChangeStartDateTime = new System.Windows.Forms.Button();
            this.btnListActivityChangeName = new System.Windows.Forms.Button();
            this.dateTimePickerListActivityChange = new System.Windows.Forms.DateTimePicker();
            this.lblListActivityStartDateTimeChange = new System.Windows.Forms.Label();
            this.txtListActivityIDChange = new System.Windows.Forms.TextBox();
            this.lblListActivityIDChange = new System.Windows.Forms.Label();
            this.txtListActivityNameChange = new System.Windows.Forms.TextBox();
            this.lblListActivityNameChange = new System.Windows.Forms.Label();
            this.changeActivity = new System.Windows.Forms.Label();
            this.dateTimePickerListActivity = new System.Windows.Forms.DateTimePicker();
            this.btnListActivityRemove = new System.Windows.Forms.Button();
            this.btnListActivityAdd = new System.Windows.Forms.Button();
            this.txtListActivityID = new System.Windows.Forms.TextBox();
            this.lblListActivityID = new System.Windows.Forms.Label();
            this.removeActivity = new System.Windows.Forms.Label();
            this.lblListActivityStartDateTime = new System.Windows.Forms.Label();
            this.lblListActivityName = new System.Windows.Forms.Label();
            this.addActivity = new System.Windows.Forms.Label();
            this.txtListActivityName = new System.Windows.Forms.TextBox();
            this.listViewListOfActivities = new System.Windows.Forms.ListView();
            this.ListOfActivitiesActivityID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ListOfActivitiesActivityStartDateTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ListOfActivitiesActivityEndDateTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ListOfActivitiesActivityName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityListOfActivitiesPictureBox = new System.Windows.Forms.PictureBox();
            this.lblListOfActivities = new System.Windows.Forms.Label();
            this.pnlActivityParticipants = new System.Windows.Forms.Panel();
            this.buttonRemoveParticipant = new System.Windows.Forms.Button();
            this.buttonAddParticipant = new System.Windows.Forms.Button();
            this.lblActivityParticipantsStudentID = new System.Windows.Forms.Label();
            this.lblActivityParticipantsParticipantID = new System.Windows.Forms.Label();
            this.txtAddStudentID = new System.Windows.Forms.TextBox();
            this.txtAddParticipantID = new System.Windows.Forms.TextBox();
            this.lbAddParticipants = new System.Windows.Forms.Label();
            this.lbActivitiesParticipantsSelectedActivity = new System.Windows.Forms.Label();
            this.listViewParticipantsActivities = new System.Windows.Forms.ListView();
            this.activityParticipantsActivitiesActivityID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantsActivitiesActivityStartDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantsActivitiesActivityEndDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantsActivitiesActivityName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewParticipants = new System.Windows.Forms.ListView();
            this.activityParticipantID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantsStudentID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantsActivityID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activityParticipantPictureBox = new System.Windows.Forms.PictureBox();
            this.lbActivityParticipant = new System.Windows.Forms.Label();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlActivitySupervisors = new System.Windows.Forms.Panel();
            this.activitySupervisorsHeaderLabel = new System.Windows.Forms.Label();
            this.activitySupervisorsActivitiesHeaderLabel = new System.Windows.Forms.Label();
            this.teacherIDLabel = new System.Windows.Forms.Label();
            this.supervisorTeacherIdTextBox = new System.Windows.Forms.TextBox();
            this.supervisorIdTextBox = new System.Windows.Forms.TextBox();
            this.addNewSupervisorLabel = new System.Windows.Forms.Label();
            this.supervisorIdLabel = new System.Windows.Forms.Label();
            this.supervisorDeleteButton = new System.Windows.Forms.Button();
            this.addSupervisorButton = new System.Windows.Forms.Button();
            this.selectedActivitySupervisorsListView = new System.Windows.Forms.ListView();
            this.activitySupervisorsSupervisorId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorsTeacherId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorsSelectedActivityId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorsSupervisorName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorsListView = new System.Windows.Forms.ListView();
            this.activitySupervisorsActivityID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorActivityStartDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorsActivityEndDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorActivityName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activitySupervisorPictureBox = new System.Windows.Forms.PictureBox();
            this.activitySupervisorLabel = new System.Windows.Forms.Label();
            this.lblRecoverPasswordResetMessage = new System.Windows.Forms.Label();
            this.buttonRecoverPasswordReset = new System.Windows.Forms.Button();
            this.pnlRecoverPassword = new System.Windows.Forms.Panel();
            this.buttonRecoverPasswordSetNewPassword = new System.Windows.Forms.Button();
            this.txtRecoverPasswordNewPassword = new System.Windows.Forms.TextBox();
            this.lblRecoverPasswordNewPassword = new System.Windows.Forms.Label();
            this.buttonRecoverPasswordCheckAnswer = new System.Windows.Forms.Button();
            this.buttonRecoverPasswordGetSecretQuestion = new System.Windows.Forms.Button();
            this.txtRecoverPasswordAnswer = new System.Windows.Forms.TextBox();
            this.txtRecoverPasswordUsername = new System.Windows.Forms.TextBox();
            this.lblRecoverPasswordSecretQuestion = new System.Windows.Forms.Label();
            this.lblRecoverPasswordUsername = new System.Windows.Forms.Label();
            this.listViewRecoverPassword = new System.Windows.Forms.ListView();
            this.lblRecoverPassword = new System.Windows.Forms.Label();
            this.pnlLoginPanel = new System.Windows.Forms.Panel();
            this.buttonRegisterUser = new System.Windows.Forms.Button();
            this.btnRecoverPasswordLoginPanel = new System.Windows.Forms.Button();
            this.btnLoginPanel = new System.Windows.Forms.Button();
            this.txtPasswordLoginPanel = new System.Windows.Forms.TextBox();
            this.txtUsernameLoginPanel = new System.Windows.Forms.TextBox();
            this.passwordLoginPanel = new System.Windows.Forms.Label();
            this.usernameLoginPanel = new System.Windows.Forms.Label();
            this.loginPanelPictureBox = new System.Windows.Forms.PictureBox();
            this.loginPanelLabel = new System.Windows.Forms.Label();
            this.pnlRegisterUser = new System.Windows.Forms.Panel();
            this.secretAnswerTextBox = new System.Windows.Forms.TextBox();
            this.secretQuestionTextBox = new System.Windows.Forms.TextBox();
            this.secretAnswerLabel = new System.Windows.Forms.Label();
            this.secretQuestionLabel = new System.Windows.Forms.Label();
            this.ToLoginFormLinkLabel = new System.Windows.Forms.LinkLabel();
            this.licenceKeyLabel = new System.Windows.Forms.Label();
            this.licenceKeyTextBox = new System.Windows.Forms.TextBox();
            this.registerButton = new System.Windows.Forms.Button();
            this.passwordRegisterTextBox = new System.Windows.Forms.TextBox();
            this.usernameRegisterTextBox = new System.Windows.Forms.TextBox();
            this.passwordRegisterLabel = new System.Windows.Forms.Label();
            this.usernameRegisterLabel = new System.Windows.Forms.Label();
            this.registerNewUserPictureBox = new System.Windows.Forms.PictureBox();
            this.registerUserLabel = new System.Windows.Forms.Label();
            this.linkLabelBackToLogin = new System.Windows.Forms.LinkLabel();
            this.supervisorDaoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.supervisorDaoBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.supervisorServiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.imgDashboard)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.pnlDashboard.SuspendLayout();
            this.pnlTeachers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roompictureBox)).BeginInit();
            this.pnlRooms.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.pnlDrinksCash.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlStudents.SuspendLayout();
            this.pnlDrinkSupplies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.drinkSuppliesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.pnlReport.SuspendLayout();
            this.pnlListOfActivities.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activityListOfActivitiesPictureBox)).BeginInit();
            this.pnlActivityParticipants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activityParticipantPictureBox)).BeginInit();
            this.pnlActivitySupervisors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activitySupervisorPictureBox)).BeginInit();
            this.pnlRecoverPassword.SuspendLayout();
            this.pnlLoginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginPanelPictureBox)).BeginInit();
            this.pnlRegisterUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.registerNewUserPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supervisorDaoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supervisorDaoBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supervisorServiceBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // imgDashboard
            // 
            this.imgDashboard.Location = new System.Drawing.Point(418, 0);
            this.imgDashboard.Margin = new System.Windows.Forms.Padding(2);
            this.imgDashboard.Name = "imgDashboard";
            this.imgDashboard.Size = new System.Drawing.Size(207, 175);
            this.imgDashboard.TabIndex = 0;
            this.imgDashboard.TabStop = false;
            this.imgDashboard.Click += new System.EventHandler(this.imgDashboard_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem,
            this.studentsToolStripMenuItem,
            this.teachersToolStripMenuItem,
            this.activitiesToolStripMenuItem,
            this.roomsToolStripMenuItem,
            this.drinksToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(2, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(901, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dashboardToolStripMenuItem
            // 
            this.dashboardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem1,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.dashboardToolStripMenuItem.Name = "dashboardToolStripMenuItem";
            this.dashboardToolStripMenuItem.Size = new System.Drawing.Size(80, 22);
            this.dashboardToolStripMenuItem.Text = "Application";
            this.dashboardToolStripMenuItem.Click += new System.EventHandler(this.dashboardToolStripMenuItem_Click);
            // 
            // dashboardToolStripMenuItem1
            // 
            this.dashboardToolStripMenuItem1.Name = "dashboardToolStripMenuItem1";
            this.dashboardToolStripMenuItem1.Size = new System.Drawing.Size(131, 22);
            this.dashboardToolStripMenuItem1.Text = "Dashboard";
            this.dashboardToolStripMenuItem1.Click += new System.EventHandler(this.dashboardToolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(128, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(65, 22);
            this.studentsToolStripMenuItem.Text = "Students";
            this.studentsToolStripMenuItem.Click += new System.EventHandler(this.studentsToolStripMenuItem_Click);
            // 
            // teachersToolStripMenuItem
            // 
            this.teachersToolStripMenuItem.Name = "teachersToolStripMenuItem";
            this.teachersToolStripMenuItem.Size = new System.Drawing.Size(64, 22);
            this.teachersToolStripMenuItem.Text = "Teachers";
            this.teachersToolStripMenuItem.Click += new System.EventHandler(this.TeachersToolStripMenuItem_Click);
            // 
            // activitiesToolStripMenuItem
            // 
            this.activitiesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listOfActivitiesToolStripMenuItem,
            this.activityParticipantsToolStripMenuItem,
            this.activitySupervisorsToolStripMenuItem});
            this.activitiesToolStripMenuItem.Name = "activitiesToolStripMenuItem";
            this.activitiesToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            this.activitiesToolStripMenuItem.Text = "Activities";
            // 
            // listOfActivitiesToolStripMenuItem
            // 
            this.listOfActivitiesToolStripMenuItem.Name = "listOfActivitiesToolStripMenuItem";
            this.listOfActivitiesToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.listOfActivitiesToolStripMenuItem.Text = "List of Activities";
            this.listOfActivitiesToolStripMenuItem.Click += new System.EventHandler(this.listOfActivitiesToolStripMenuItem_Click);
            // 
            // activityParticipantsToolStripMenuItem
            // 
            this.activityParticipantsToolStripMenuItem.Name = "activityParticipantsToolStripMenuItem";
            this.activityParticipantsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.activityParticipantsToolStripMenuItem.Text = "Activity Participants";
            this.activityParticipantsToolStripMenuItem.Click += new System.EventHandler(this.activityParticipantsToolStripMenuItem_Click);
            // 
            // activitySupervisorsToolStripMenuItem
            // 
            this.activitySupervisorsToolStripMenuItem.Name = "activitySupervisorsToolStripMenuItem";
            this.activitySupervisorsToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.activitySupervisorsToolStripMenuItem.Text = "Activity Supervisors";
            this.activitySupervisorsToolStripMenuItem.Click += new System.EventHandler(this.activitySupervisorsToolStripMenuItem_Click);
            // 
            // roomsToolStripMenuItem
            // 
            this.roomsToolStripMenuItem.Name = "roomsToolStripMenuItem";
            this.roomsToolStripMenuItem.Size = new System.Drawing.Size(56, 22);
            this.roomsToolStripMenuItem.Text = "Rooms";
            this.roomsToolStripMenuItem.Click += new System.EventHandler(this.roomsToolStripMenuItem_Click);
            // 
            // drinksToolStripMenuItem
            // 
            this.drinksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.drinkSuppliesToolStripMenuItem,
            this.cashRegisterToolStripMenuItem,
            this.revenueReportToolStripMenuItem});
            this.drinksToolStripMenuItem.Name = "drinksToolStripMenuItem";
            this.drinksToolStripMenuItem.Size = new System.Drawing.Size(52, 22);
            this.drinksToolStripMenuItem.Text = "Drinks";
            this.drinksToolStripMenuItem.Click += new System.EventHandler(this.DrinkToolStripMenuItem_Click);
            // 
            // drinkSuppliesToolStripMenuItem
            // 
            this.drinkSuppliesToolStripMenuItem.Name = "drinkSuppliesToolStripMenuItem";
            this.drinkSuppliesToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.drinkSuppliesToolStripMenuItem.Text = "Drink supplies";
            this.drinkSuppliesToolStripMenuItem.Click += new System.EventHandler(this.drinksSuppliesToolStripMenuItem_Click);
            // 
            // cashRegisterToolStripMenuItem
            // 
            this.cashRegisterToolStripMenuItem.Name = "cashRegisterToolStripMenuItem";
            this.cashRegisterToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.cashRegisterToolStripMenuItem.Text = "Cash register";
            this.cashRegisterToolStripMenuItem.Click += new System.EventHandler(this.cashRegisterToolStripMenuItem_Click);
            // 
            // revenueReportToolStripMenuItem
            // 
            this.revenueReportToolStripMenuItem.Name = "revenueReportToolStripMenuItem";
            this.revenueReportToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.revenueReportToolStripMenuItem.Text = "Revenue report";
            this.revenueReportToolStripMenuItem.Click += new System.EventHandler(this.revenueReportToolStripMenuItem_Click);
            // 
            // pnlDashboard
            // 
            this.pnlDashboard.Controls.Add(this.lbl_Dashboard);
            this.pnlDashboard.Controls.Add(this.imgDashboard);
            this.pnlDashboard.Location = new System.Drawing.Point(8, 26);
            this.pnlDashboard.Margin = new System.Windows.Forms.Padding(2);
            this.pnlDashboard.Name = "pnlDashboard";
            this.pnlDashboard.Size = new System.Drawing.Size(625, 295);
            this.pnlDashboard.TabIndex = 2;
            // 
            // lbl_Dashboard
            // 
            this.lbl_Dashboard.AutoSize = true;
            this.lbl_Dashboard.Location = new System.Drawing.Point(9, 8);
            this.lbl_Dashboard.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Dashboard.Name = "lbl_Dashboard";
            this.lbl_Dashboard.Size = new System.Drawing.Size(185, 13);
            this.lbl_Dashboard.TabIndex = 1;
            this.lbl_Dashboard.Text = "Welcome to the Someren Application!";
            // 
            // pnlTeachers
            // 
            this.pnlTeachers.Controls.Add(this.listViewTeachers);
            this.pnlTeachers.Controls.Add(this.roompictureBox);
            this.pnlTeachers.Controls.Add(this.lbl_Teachers);
            this.pnlTeachers.Location = new System.Drawing.Point(8, 26);
            this.pnlTeachers.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTeachers.Name = "pnlTeachers";
            this.pnlTeachers.Size = new System.Drawing.Size(625, 290);
            this.pnlTeachers.TabIndex = 5;
            // 
            // listViewTeachers
            // 
            this.listViewTeachers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.teacherID,
            this.teacherName,
            this.roomID});
            this.listViewTeachers.HideSelection = false;
            this.listViewTeachers.Location = new System.Drawing.Point(11, 27);
            this.listViewTeachers.Margin = new System.Windows.Forms.Padding(2);
            this.listViewTeachers.Name = "listViewTeachers";
            this.listViewTeachers.Size = new System.Drawing.Size(512, 201);
            this.listViewTeachers.TabIndex = 5;
            this.listViewTeachers.UseCompatibleStateImageBehavior = false;
            // 
            // teacherID
            // 
            this.teacherID.Text = "ID";
            this.teacherID.Width = 30;
            // 
            // teacherName
            // 
            this.teacherName.Text = "Name";
            this.teacherName.Width = 120;
            // 
            // roomID
            // 
            this.roomID.Text = "Room ID";
            this.roomID.Width = 80;
            // 
            // roompictureBox
            // 
            this.roompictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.roompictureBox.InitialImage = null;
            this.roompictureBox.Location = new System.Drawing.Point(537, 0);
            this.roompictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.roompictureBox.Name = "roompictureBox";
            this.roompictureBox.Size = new System.Drawing.Size(87, 80);
            this.roompictureBox.TabIndex = 0;
            this.roompictureBox.TabStop = false;
            // 
            // lbl_Teachers
            // 
            this.lbl_Teachers.AutoSize = true;
            this.lbl_Teachers.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Teachers.Location = new System.Drawing.Point(7, 6);
            this.lbl_Teachers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Teachers.Name = "lbl_Teachers";
            this.lbl_Teachers.Size = new System.Drawing.Size(115, 29);
            this.lbl_Teachers.TabIndex = 3;
            this.lbl_Teachers.Text = "Teachers";
            // 
            // pnlRooms
            // 
            this.pnlRooms.Controls.Add(this.listViewRooms);
            this.pnlRooms.Controls.Add(this.pictureBox2);
            this.pnlRooms.Controls.Add(this.label1);
            this.pnlRooms.Location = new System.Drawing.Point(8, 27);
            this.pnlRooms.Margin = new System.Windows.Forms.Padding(2);
            this.pnlRooms.Name = "pnlRooms";
            this.pnlRooms.Size = new System.Drawing.Size(625, 289);
            this.pnlRooms.TabIndex = 5;
            // 
            // listViewRooms
            // 
            this.listViewRooms.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.RoomRoomID,
            this.roomNumber,
            this.roomCapacity,
            this.roomType});
            this.listViewRooms.HideSelection = false;
            this.listViewRooms.Location = new System.Drawing.Point(11, 27);
            this.listViewRooms.Margin = new System.Windows.Forms.Padding(2);
            this.listViewRooms.Name = "listViewRooms";
            this.listViewRooms.Size = new System.Drawing.Size(512, 201);
            this.listViewRooms.TabIndex = 5;
            this.listViewRooms.UseCompatibleStateImageBehavior = false;
            // 
            // RoomRoomID
            // 
            this.RoomRoomID.Text = "ID";
            // 
            // roomNumber
            // 
            this.roomNumber.Text = "Number";
            // 
            // roomCapacity
            // 
            this.roomCapacity.Text = "Capacity";
            // 
            // roomType
            // 
            this.roomType.Text = "Type";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(537, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(87, 80);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Students";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Start Date:";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Name";
            this.columnHeader3.Width = 30;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(805, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(130, 123);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(591, 309);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(186, 37);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // pnlDrinksCash
            // 
            this.pnlDrinksCash.Controls.Add(this.lblTotalDrinksCash);
            this.pnlDrinksCash.Controls.Add(this.TotalDrinksCash);
            this.pnlDrinksCash.Controls.Add(this.btnBuy);
            this.pnlDrinksCash.Controls.Add(this.checkedListBoxDrinks);
            this.pnlDrinksCash.Controls.Add(this.listViewDrinkStudents);
            this.pnlDrinksCash.Controls.Add(this.pictureBox3);
            this.pnlDrinksCash.Controls.Add(this.lbl_CashRegister);
            this.pnlDrinksCash.Location = new System.Drawing.Point(5, 26);
            this.pnlDrinksCash.Margin = new System.Windows.Forms.Padding(1);
            this.pnlDrinksCash.Name = "pnlDrinksCash";
            this.pnlDrinksCash.Size = new System.Drawing.Size(625, 282);
            this.pnlDrinksCash.TabIndex = 6;
            // 
            // lblTotalDrinksCash
            // 
            this.lblTotalDrinksCash.AutoSize = true;
            this.lblTotalDrinksCash.Location = new System.Drawing.Point(482, 191);
            this.lblTotalDrinksCash.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalDrinksCash.Name = "lblTotalDrinksCash";
            this.lblTotalDrinksCash.Size = new System.Drawing.Size(28, 13);
            this.lblTotalDrinksCash.TabIndex = 10;
            this.lblTotalDrinksCash.Text = "0.00";
            // 
            // TotalDrinksCash
            // 
            this.TotalDrinksCash.AutoSize = true;
            this.TotalDrinksCash.Location = new System.Drawing.Point(442, 190);
            this.TotalDrinksCash.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TotalDrinksCash.Name = "TotalDrinksCash";
            this.TotalDrinksCash.Size = new System.Drawing.Size(37, 13);
            this.TotalDrinksCash.TabIndex = 9;
            this.TotalDrinksCash.Text = "Total: ";
            // 
            // btnBuy
            // 
            this.btnBuy.Location = new System.Drawing.Point(459, 214);
            this.btnBuy.Margin = new System.Windows.Forms.Padding(2);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(107, 24);
            this.btnBuy.TabIndex = 8;
            this.btnBuy.Text = "Buy";
            this.btnBuy.UseVisualStyleBackColor = true;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // checkedListBoxDrinks
            // 
            this.checkedListBoxDrinks.CheckOnClick = true;
            this.checkedListBoxDrinks.FormattingEnabled = true;
            this.checkedListBoxDrinks.Location = new System.Drawing.Point(194, 39);
            this.checkedListBoxDrinks.Margin = new System.Windows.Forms.Padding(2);
            this.checkedListBoxDrinks.Name = "checkedListBoxDrinks";
            this.checkedListBoxDrinks.Size = new System.Drawing.Size(228, 199);
            this.checkedListBoxDrinks.TabIndex = 6;
            this.checkedListBoxDrinks.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxDrinks_SelectedIndexChanged);
            // 
            // listViewDrinkStudents
            // 
            this.listViewDrinkStudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DrinkStudentID,
            this.DrinkStudentName});
            this.listViewDrinkStudents.FullRowSelect = true;
            this.listViewDrinkStudents.GridLines = true;
            this.listViewDrinkStudents.HideSelection = false;
            this.listViewDrinkStudents.Location = new System.Drawing.Point(7, 39);
            this.listViewDrinkStudents.Margin = new System.Windows.Forms.Padding(2);
            this.listViewDrinkStudents.Name = "listViewDrinkStudents";
            this.listViewDrinkStudents.Size = new System.Drawing.Size(167, 199);
            this.listViewDrinkStudents.TabIndex = 5;
            this.listViewDrinkStudents.UseCompatibleStateImageBehavior = false;
            // 
            // DrinkStudentID
            // 
            this.DrinkStudentID.Text = "ID";
            this.DrinkStudentID.Width = 30;
            // 
            // DrinkStudentName
            // 
            this.DrinkStudentName.Text = "Name";
            this.DrinkStudentName.Width = 120;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(537, 0);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(87, 80);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // lbl_CashRegister
            // 
            this.lbl_CashRegister.AutoSize = true;
            this.lbl_CashRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CashRegister.Location = new System.Drawing.Point(5, 4);
            this.lbl_CashRegister.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbl_CashRegister.Name = "lbl_CashRegister";
            this.lbl_CashRegister.Size = new System.Drawing.Size(165, 29);
            this.lbl_CashRegister.TabIndex = 3;
            this.lbl_CashRegister.Text = "Cash Register";
            // 
            // lbl_Students
            // 
            this.lbl_Students.AutoSize = true;
            this.lbl_Students.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Students.Location = new System.Drawing.Point(10, 10);
            this.lbl_Students.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Students.Name = "lbl_Students";
            this.lbl_Students.Size = new System.Drawing.Size(107, 29);
            this.lbl_Students.TabIndex = 3;
            this.lbl_Students.Text = "Students";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(805, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 123);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // listViewStudents
            // 
            this.listViewStudents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.studentID,
            this.studentName,
            this.studentDOB});
            this.listViewStudents.HideSelection = false;
            this.listViewStudents.Location = new System.Drawing.Point(16, 42);
            this.listViewStudents.Margin = new System.Windows.Forms.Padding(2);
            this.listViewStudents.Name = "listViewStudents";
            this.listViewStudents.Size = new System.Drawing.Size(766, 307);
            this.listViewStudents.TabIndex = 5;
            this.listViewStudents.UseCompatibleStateImageBehavior = false;
            // 
            // studentID
            // 
            this.studentID.Text = "ID";
            this.studentID.Width = 40;
            // 
            // studentName
            // 
            this.studentName.Text = "Name";
            this.studentName.Width = 100;
            // 
            // studentDOB
            // 
            this.studentDOB.Text = "Date of Birth";
            this.studentDOB.Width = 80;
            // 
            // pnlStudents
            // 
            this.pnlStudents.Controls.Add(this.listViewStudents);
            this.pnlStudents.Controls.Add(this.pictureBox1);
            this.pnlStudents.Controls.Add(this.lbl_Students);
            this.pnlStudents.Location = new System.Drawing.Point(12, 27);
            this.pnlStudents.Margin = new System.Windows.Forms.Padding(2);
            this.pnlStudents.Name = "pnlStudents";
            this.pnlStudents.Size = new System.Drawing.Size(621, 353);
            this.pnlStudents.TabIndex = 4;
            // 
            // pnlDrinkSupplies
            // 
            this.pnlDrinkSupplies.Controls.Add(this.idTextBox);
            this.pnlDrinkSupplies.Controls.Add(this.idLabel);
            this.pnlDrinkSupplies.Controls.Add(this.changeNameButton);
            this.pnlDrinkSupplies.Controls.Add(this.newNameLabel);
            this.pnlDrinkSupplies.Controls.Add(this.changeNameTextBox);
            this.pnlDrinkSupplies.Controls.Add(this.amountLabel);
            this.pnlDrinkSupplies.Controls.Add(this.changeAmountTextBox);
            this.pnlDrinkSupplies.Controls.Add(this.updateAmountButton);
            this.pnlDrinkSupplies.Controls.Add(this.listViewDrinkSupplies);
            this.pnlDrinkSupplies.Controls.Add(this.drinkSuppliesPictureBox);
            this.pnlDrinkSupplies.Controls.Add(this.drinkSuppliesLabel);
            this.pnlDrinkSupplies.Location = new System.Drawing.Point(8, 27);
            this.pnlDrinkSupplies.Margin = new System.Windows.Forms.Padding(1);
            this.pnlDrinkSupplies.Name = "pnlDrinkSupplies";
            this.pnlDrinkSupplies.Size = new System.Drawing.Size(625, 291);
            this.pnlDrinkSupplies.TabIndex = 7;
            // 
            // idTextBox
            // 
            this.idTextBox.Location = new System.Drawing.Point(482, 138);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(124, 20);
            this.idTextBox.TabIndex = 15;
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.Location = new System.Drawing.Point(457, 141);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(19, 13);
            this.idLabel.TabIndex = 14;
            this.idLabel.Text = "Id:";
            // 
            // changeNameButton
            // 
            this.changeNameButton.Location = new System.Drawing.Point(482, 198);
            this.changeNameButton.Margin = new System.Windows.Forms.Padding(2);
            this.changeNameButton.Name = "changeNameButton";
            this.changeNameButton.Size = new System.Drawing.Size(124, 24);
            this.changeNameButton.TabIndex = 13;
            this.changeNameButton.Text = "Update";
            this.changeNameButton.UseVisualStyleBackColor = true;
            this.changeNameButton.Click += new System.EventHandler(this.changeNameButton_Click);
            // 
            // newNameLabel
            // 
            this.newNameLabel.AutoSize = true;
            this.newNameLabel.Location = new System.Drawing.Point(415, 176);
            this.newNameLabel.Name = "newNameLabel";
            this.newNameLabel.Size = new System.Drawing.Size(61, 13);
            this.newNameLabel.TabIndex = 12;
            this.newNameLabel.Text = "New name:";
            // 
            // changeNameTextBox
            // 
            this.changeNameTextBox.Location = new System.Drawing.Point(482, 173);
            this.changeNameTextBox.Name = "changeNameTextBox";
            this.changeNameTextBox.Size = new System.Drawing.Size(124, 20);
            this.changeNameTextBox.TabIndex = 11;
            // 
            // amountLabel
            // 
            this.amountLabel.AutoSize = true;
            this.amountLabel.Location = new System.Drawing.Point(406, 235);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(70, 13);
            this.amountLabel.TabIndex = 10;
            this.amountLabel.Text = "New amount:";
            // 
            // changeAmountTextBox
            // 
            this.changeAmountTextBox.Location = new System.Drawing.Point(482, 232);
            this.changeAmountTextBox.Name = "changeAmountTextBox";
            this.changeAmountTextBox.Size = new System.Drawing.Size(124, 20);
            this.changeAmountTextBox.TabIndex = 9;
            // 
            // updateAmountButton
            // 
            this.updateAmountButton.Location = new System.Drawing.Point(482, 257);
            this.updateAmountButton.Margin = new System.Windows.Forms.Padding(2);
            this.updateAmountButton.Name = "updateAmountButton";
            this.updateAmountButton.Size = new System.Drawing.Size(124, 24);
            this.updateAmountButton.TabIndex = 8;
            this.updateAmountButton.Text = "Update";
            this.updateAmountButton.UseVisualStyleBackColor = true;
            this.updateAmountButton.Click += new System.EventHandler(this.updateAmountButton_Click);
            // 
            // listViewDrinkSupplies
            // 
            this.listViewDrinkSupplies.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.DrinkId,
            this.DrinkName,
            this.DrinkAmountInStock,
            this.DrinkSalesPrice});
            this.listViewDrinkSupplies.FullRowSelect = true;
            this.listViewDrinkSupplies.GridLines = true;
            this.listViewDrinkSupplies.HideSelection = false;
            this.listViewDrinkSupplies.Location = new System.Drawing.Point(12, 35);
            this.listViewDrinkSupplies.Margin = new System.Windows.Forms.Padding(2);
            this.listViewDrinkSupplies.Name = "listViewDrinkSupplies";
            this.listViewDrinkSupplies.Size = new System.Drawing.Size(371, 199);
            this.listViewDrinkSupplies.TabIndex = 5;
            this.listViewDrinkSupplies.UseCompatibleStateImageBehavior = false;
            // 
            // DrinkId
            // 
            this.DrinkId.DisplayIndex = 3;
            this.DrinkId.Text = "Id";
            // 
            // DrinkName
            // 
            this.DrinkName.DisplayIndex = 0;
            this.DrinkName.Text = "Name";
            this.DrinkName.Width = 80;
            // 
            // DrinkAmountInStock
            // 
            this.DrinkAmountInStock.DisplayIndex = 1;
            this.DrinkAmountInStock.Text = "Amount";
            // 
            // DrinkSalesPrice
            // 
            this.DrinkSalesPrice.DisplayIndex = 2;
            this.DrinkSalesPrice.Text = "Price";
            // 
            // drinkSuppliesPictureBox
            // 
            this.drinkSuppliesPictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.drinkSuppliesPictureBox.InitialImage = null;
            this.drinkSuppliesPictureBox.Location = new System.Drawing.Point(506, 0);
            this.drinkSuppliesPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.drinkSuppliesPictureBox.Name = "drinkSuppliesPictureBox";
            this.drinkSuppliesPictureBox.Size = new System.Drawing.Size(118, 89);
            this.drinkSuppliesPictureBox.TabIndex = 0;
            this.drinkSuppliesPictureBox.TabStop = false;
            // 
            // drinkSuppliesLabel
            // 
            this.drinkSuppliesLabel.AutoSize = true;
            this.drinkSuppliesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drinkSuppliesLabel.Location = new System.Drawing.Point(5, 4);
            this.drinkSuppliesLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.drinkSuppliesLabel.Name = "drinkSuppliesLabel";
            this.drinkSuppliesLabel.Size = new System.Drawing.Size(170, 29);
            this.drinkSuppliesLabel.TabIndex = 3;
            this.drinkSuppliesLabel.Text = "Drink Supplies";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(204, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 16);
            this.label3.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(204, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(204, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(38, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 16);
            this.label6.TabIndex = 15;
            this.label6.Text = "Number of customers:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(38, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Turnover:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(38, 273);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "Number of sales:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(300, 199);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(122, 43);
            this.button2.TabIndex = 12;
            this.button2.Text = "Generate Revenue Report";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(37, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Start Date:";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "ID";
            this.columnHeader4.Width = 40;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Name";
            this.columnHeader5.Width = 100;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Date of Birth";
            this.columnHeader6.Width = 80;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SomerenUI.Properties.Resources.someren;
            this.pictureBox5.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.InitialImage")));
            this.pictureBox5.Location = new System.Drawing.Point(805, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(130, 123);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // pnlReport
            // 
            this.pnlReport.BackColor = System.Drawing.SystemColors.Control;
            this.pnlReport.Controls.Add(this.label2);
            this.pnlReport.Controls.Add(this.pictureBox4);
            this.pnlReport.Controls.Add(this.txtNumberOfCustomers);
            this.pnlReport.Controls.Add(this.txtTurnover);
            this.pnlReport.Controls.Add(this.txtNumberOfSales);
            this.pnlReport.Controls.Add(this.lbNumberOfCustomers);
            this.pnlReport.Controls.Add(this.lbTurnover);
            this.pnlReport.Controls.Add(this.lbNumberOfSales);
            this.pnlReport.Controls.Add(this.buttonGenerate);
            this.pnlReport.Controls.Add(this.monthCalendarStartDate);
            this.pnlReport.Controls.Add(this.listViewReport);
            this.pnlReport.Controls.Add(this.lblReport);
            this.pnlReport.Location = new System.Drawing.Point(5, 26);
            this.pnlReport.Name = "pnlReport";
            this.pnlReport.Size = new System.Drawing.Size(628, 350);
            this.pnlReport.TabIndex = 16;
            // 
            // txtNumberOfCustomers
            // 
            this.txtNumberOfCustomers.AutoSize = true;
            this.txtNumberOfCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumberOfCustomers.Location = new System.Drawing.Point(204, 325);
            this.txtNumberOfCustomers.Name = "txtNumberOfCustomers";
            this.txtNumberOfCustomers.Size = new System.Drawing.Size(0, 16);
            this.txtNumberOfCustomers.TabIndex = 18;
            // 
            // txtTurnover
            // 
            this.txtTurnover.AutoSize = true;
            this.txtTurnover.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTurnover.Location = new System.Drawing.Point(204, 299);
            this.txtTurnover.Name = "txtTurnover";
            this.txtTurnover.Size = new System.Drawing.Size(0, 16);
            this.txtTurnover.TabIndex = 17;
            // 
            // txtNumberOfSales
            // 
            this.txtNumberOfSales.AutoSize = true;
            this.txtNumberOfSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumberOfSales.Location = new System.Drawing.Point(204, 271);
            this.txtNumberOfSales.Name = "txtNumberOfSales";
            this.txtNumberOfSales.Size = new System.Drawing.Size(0, 16);
            this.txtNumberOfSales.TabIndex = 16;
            // 
            // lbNumberOfCustomers
            // 
            this.lbNumberOfCustomers.AutoSize = true;
            this.lbNumberOfCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumberOfCustomers.Location = new System.Drawing.Point(38, 325);
            this.lbNumberOfCustomers.Name = "lbNumberOfCustomers";
            this.lbNumberOfCustomers.Size = new System.Drawing.Size(138, 16);
            this.lbNumberOfCustomers.TabIndex = 15;
            this.lbNumberOfCustomers.Text = "Number of customers:";
            // 
            // lbTurnover
            // 
            this.lbTurnover.AutoSize = true;
            this.lbTurnover.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTurnover.Location = new System.Drawing.Point(38, 299);
            this.lbTurnover.Name = "lbTurnover";
            this.lbTurnover.Size = new System.Drawing.Size(65, 16);
            this.lbTurnover.TabIndex = 14;
            this.lbTurnover.Text = "Turnover:";
            // 
            // lbNumberOfSales
            // 
            this.lbNumberOfSales.AutoSize = true;
            this.lbNumberOfSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumberOfSales.Location = new System.Drawing.Point(38, 273);
            this.lbNumberOfSales.Name = "lbNumberOfSales";
            this.lbNumberOfSales.Size = new System.Drawing.Size(109, 16);
            this.lbNumberOfSales.TabIndex = 13;
            this.lbNumberOfSales.Text = "Number of sales:";
            // 
            // buttonGenerate
            // 
            this.buttonGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGenerate.Location = new System.Drawing.Point(300, 199);
            this.buttonGenerate.Name = "buttonGenerate";
            this.buttonGenerate.Size = new System.Drawing.Size(122, 43);
            this.buttonGenerate.TabIndex = 12;
            this.buttonGenerate.Text = "Generate Revenue Report";
            this.buttonGenerate.UseVisualStyleBackColor = true;
            this.buttonGenerate.Click += new System.EventHandler(this.buttonGenerate_Click);
            // 
            // monthCalendarStartDate
            // 
            this.monthCalendarStartDate.Location = new System.Drawing.Point(40, 80);
            this.monthCalendarStartDate.MaxSelectionCount = 100;
            this.monthCalendarStartDate.Name = "monthCalendarStartDate";
            this.monthCalendarStartDate.TabIndex = 6;
            // 
            // listViewReport
            // 
            this.listViewReport.HideSelection = false;
            this.listViewReport.Location = new System.Drawing.Point(16, 42);
            this.listViewReport.Name = "listViewReport";
            this.listViewReport.Size = new System.Drawing.Size(606, 308);
            this.listViewReport.TabIndex = 11;
            this.listViewReport.UseCompatibleStateImageBehavior = false;
            // 
            // lblReport
            // 
            this.lblReport.AutoSize = true;
            this.lblReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReport.Location = new System.Drawing.Point(10, 10);
            this.lblReport.Name = "lblReport";
            this.lblReport.Size = new System.Drawing.Size(188, 29);
            this.lblReport.TabIndex = 3;
            this.lblReport.Text = "Revenue Report";
            // 
            // pnlListOfActivities
            // 
            this.pnlListOfActivities.Controls.Add(this.btnListActivityChangeEndDateTime);
            this.pnlListOfActivities.Controls.Add(this.endDateTimePickerListActivityChange);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityEndDateTimeChange);
            this.pnlListOfActivities.Controls.Add(this.endDateTimePickerListActivity);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityEndDateTime);
            this.pnlListOfActivities.Controls.Add(this.lblDeviderLine1);
            this.pnlListOfActivities.Controls.Add(this.lblDeviderLine2);
            this.pnlListOfActivities.Controls.Add(this.btnListActivityChangeStartDateTime);
            this.pnlListOfActivities.Controls.Add(this.btnListActivityChangeName);
            this.pnlListOfActivities.Controls.Add(this.dateTimePickerListActivityChange);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityStartDateTimeChange);
            this.pnlListOfActivities.Controls.Add(this.txtListActivityIDChange);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityIDChange);
            this.pnlListOfActivities.Controls.Add(this.txtListActivityNameChange);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityNameChange);
            this.pnlListOfActivities.Controls.Add(this.changeActivity);
            this.pnlListOfActivities.Controls.Add(this.dateTimePickerListActivity);
            this.pnlListOfActivities.Controls.Add(this.btnListActivityRemove);
            this.pnlListOfActivities.Controls.Add(this.btnListActivityAdd);
            this.pnlListOfActivities.Controls.Add(this.txtListActivityID);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityID);
            this.pnlListOfActivities.Controls.Add(this.removeActivity);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityStartDateTime);
            this.pnlListOfActivities.Controls.Add(this.lblListActivityName);
            this.pnlListOfActivities.Controls.Add(this.addActivity);
            this.pnlListOfActivities.Controls.Add(this.txtListActivityName);
            this.pnlListOfActivities.Controls.Add(this.listViewListOfActivities);
            this.pnlListOfActivities.Controls.Add(this.activityListOfActivitiesPictureBox);
            this.pnlListOfActivities.Controls.Add(this.lblListOfActivities);
            this.pnlListOfActivities.Location = new System.Drawing.Point(0, 32);
            this.pnlListOfActivities.Margin = new System.Windows.Forms.Padding(2);
            this.pnlListOfActivities.Name = "pnlListOfActivities";
            this.pnlListOfActivities.Size = new System.Drawing.Size(890, 489);
            this.pnlListOfActivities.TabIndex = 17;
            // 
            // btnListActivityChangeEndDateTime
            // 
            this.btnListActivityChangeEndDateTime.Location = new System.Drawing.Point(678, 437);
            this.btnListActivityChangeEndDateTime.Name = "btnListActivityChangeEndDateTime";
            this.btnListActivityChangeEndDateTime.Size = new System.Drawing.Size(146, 23);
            this.btnListActivityChangeEndDateTime.TabIndex = 32;
            this.btnListActivityChangeEndDateTime.Text = "Change End Day + Time";
            this.btnListActivityChangeEndDateTime.UseVisualStyleBackColor = true;
            this.btnListActivityChangeEndDateTime.Click += new System.EventHandler(this.btnListActivityChangeEndDateTime_Click);
            // 
            // endDateTimePickerListActivityChange
            // 
            this.endDateTimePickerListActivityChange.CustomFormat = "yyyy/MM/dd hh:mm:ss tt";
            this.endDateTimePickerListActivityChange.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endDateTimePickerListActivityChange.Location = new System.Drawing.Point(678, 407);
            this.endDateTimePickerListActivityChange.Name = "endDateTimePickerListActivityChange";
            this.endDateTimePickerListActivityChange.Size = new System.Drawing.Size(200, 20);
            this.endDateTimePickerListActivityChange.TabIndex = 31;
            // 
            // lblListActivityEndDateTimeChange
            // 
            this.lblListActivityEndDateTimeChange.AutoSize = true;
            this.lblListActivityEndDateTimeChange.Location = new System.Drawing.Point(680, 391);
            this.lblListActivityEndDateTimeChange.Name = "lblListActivityEndDateTimeChange";
            this.lblListActivityEndDateTimeChange.Size = new System.Drawing.Size(111, 13);
            this.lblListActivityEndDateTimeChange.TabIndex = 30;
            this.lblListActivityEndDateTimeChange.Text = "New End Day + Time:";
            // 
            // endDateTimePickerListActivity
            // 
            this.endDateTimePickerListActivity.CustomFormat = "yyyy/MM/dd hh:mm:ss tt";
            this.endDateTimePickerListActivity.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endDateTimePickerListActivity.Location = new System.Drawing.Point(584, 110);
            this.endDateTimePickerListActivity.Name = "endDateTimePickerListActivity";
            this.endDateTimePickerListActivity.Size = new System.Drawing.Size(200, 20);
            this.endDateTimePickerListActivity.TabIndex = 29;
            // 
            // lblListActivityEndDateTime
            // 
            this.lblListActivityEndDateTime.AutoSize = true;
            this.lblListActivityEndDateTime.Location = new System.Drawing.Point(582, 83);
            this.lblListActivityEndDateTime.Name = "lblListActivityEndDateTime";
            this.lblListActivityEndDateTime.Size = new System.Drawing.Size(86, 13);
            this.lblListActivityEndDateTime.TabIndex = 28;
            this.lblListActivityEndDateTime.Text = "End Day + Time:";
            // 
            // lblDeviderLine1
            // 
            this.lblDeviderLine1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDeviderLine1.Location = new System.Drawing.Point(340, 175);
            this.lblDeviderLine1.Name = "lblDeviderLine1";
            this.lblDeviderLine1.Size = new System.Drawing.Size(513, 1);
            this.lblDeviderLine1.TabIndex = 26;
            // 
            // lblDeviderLine2
            // 
            this.lblDeviderLine2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDeviderLine2.Location = new System.Drawing.Point(340, 305);
            this.lblDeviderLine2.Name = "lblDeviderLine2";
            this.lblDeviderLine2.Size = new System.Drawing.Size(513, 1);
            this.lblDeviderLine2.TabIndex = 27;
            // 
            // btnListActivityChangeStartDateTime
            // 
            this.btnListActivityChangeStartDateTime.Location = new System.Drawing.Point(468, 437);
            this.btnListActivityChangeStartDateTime.Name = "btnListActivityChangeStartDateTime";
            this.btnListActivityChangeStartDateTime.Size = new System.Drawing.Size(146, 23);
            this.btnListActivityChangeStartDateTime.TabIndex = 25;
            this.btnListActivityChangeStartDateTime.Text = "Change Start Day + Time";
            this.btnListActivityChangeStartDateTime.UseVisualStyleBackColor = true;
            this.btnListActivityChangeStartDateTime.Click += new System.EventHandler(this.btnListActivityChangeDateTime_Click);
            // 
            // btnListActivityChangeName
            // 
            this.btnListActivityChangeName.Location = new System.Drawing.Point(340, 437);
            this.btnListActivityChangeName.Name = "btnListActivityChangeName";
            this.btnListActivityChangeName.Size = new System.Drawing.Size(102, 23);
            this.btnListActivityChangeName.TabIndex = 24;
            this.btnListActivityChangeName.Text = "Change Name";
            this.btnListActivityChangeName.UseVisualStyleBackColor = true;
            this.btnListActivityChangeName.Click += new System.EventHandler(this.btnListActivityChangeName_Click);
            // 
            // dateTimePickerListActivityChange
            // 
            this.dateTimePickerListActivityChange.CustomFormat = "yyyy/MM/dd hh:mm:ss tt";
            this.dateTimePickerListActivityChange.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerListActivityChange.Location = new System.Drawing.Point(450, 407);
            this.dateTimePickerListActivityChange.Name = "dateTimePickerListActivityChange";
            this.dateTimePickerListActivityChange.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerListActivityChange.TabIndex = 23;
            // 
            // lblListActivityStartDateTimeChange
            // 
            this.lblListActivityStartDateTimeChange.AutoSize = true;
            this.lblListActivityStartDateTimeChange.Location = new System.Drawing.Point(452, 391);
            this.lblListActivityStartDateTimeChange.Name = "lblListActivityStartDateTimeChange";
            this.lblListActivityStartDateTimeChange.Size = new System.Drawing.Size(114, 13);
            this.lblListActivityStartDateTimeChange.TabIndex = 22;
            this.lblListActivityStartDateTimeChange.Text = "New Start Day + Time:";
            // 
            // txtListActivityIDChange
            // 
            this.txtListActivityIDChange.Location = new System.Drawing.Point(340, 353);
            this.txtListActivityIDChange.Name = "txtListActivityIDChange";
            this.txtListActivityIDChange.Size = new System.Drawing.Size(100, 20);
            this.txtListActivityIDChange.TabIndex = 21;
            // 
            // lblListActivityIDChange
            // 
            this.lblListActivityIDChange.AutoSize = true;
            this.lblListActivityIDChange.Location = new System.Drawing.Point(339, 335);
            this.lblListActivityIDChange.Name = "lblListActivityIDChange";
            this.lblListActivityIDChange.Size = new System.Drawing.Size(21, 13);
            this.lblListActivityIDChange.TabIndex = 20;
            this.lblListActivityIDChange.Text = "ID:";
            // 
            // txtListActivityNameChange
            // 
            this.txtListActivityNameChange.Location = new System.Drawing.Point(340, 407);
            this.txtListActivityNameChange.Name = "txtListActivityNameChange";
            this.txtListActivityNameChange.Size = new System.Drawing.Size(100, 20);
            this.txtListActivityNameChange.TabIndex = 19;
            // 
            // lblListActivityNameChange
            // 
            this.lblListActivityNameChange.AutoSize = true;
            this.lblListActivityNameChange.Location = new System.Drawing.Point(339, 391);
            this.lblListActivityNameChange.Name = "lblListActivityNameChange";
            this.lblListActivityNameChange.Size = new System.Drawing.Size(63, 13);
            this.lblListActivityNameChange.TabIndex = 18;
            this.lblListActivityNameChange.Text = "New Name:";
            // 
            // changeActivity
            // 
            this.changeActivity.AutoSize = true;
            this.changeActivity.Location = new System.Drawing.Point(339, 318);
            this.changeActivity.Name = "changeActivity";
            this.changeActivity.Size = new System.Drawing.Size(83, 13);
            this.changeActivity.TabIndex = 17;
            this.changeActivity.Text = "Change activity:";
            // 
            // dateTimePickerListActivity
            // 
            this.dateTimePickerListActivity.CustomFormat = "yyyy/MM/dd hh:mm:ss tt";
            this.dateTimePickerListActivity.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerListActivity.Location = new System.Drawing.Point(341, 110);
            this.dateTimePickerListActivity.Name = "dateTimePickerListActivity";
            this.dateTimePickerListActivity.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerListActivity.TabIndex = 16;
            // 
            // btnListActivityRemove
            // 
            this.btnListActivityRemove.Location = new System.Drawing.Point(342, 261);
            this.btnListActivityRemove.Name = "btnListActivityRemove";
            this.btnListActivityRemove.Size = new System.Drawing.Size(75, 23);
            this.btnListActivityRemove.TabIndex = 15;
            this.btnListActivityRemove.Text = "Remove";
            this.btnListActivityRemove.UseVisualStyleBackColor = true;
            this.btnListActivityRemove.Click += new System.EventHandler(this.btnListActivityRemove_Click);
            // 
            // btnListActivityAdd
            // 
            this.btnListActivityAdd.Location = new System.Drawing.Point(340, 143);
            this.btnListActivityAdd.Name = "btnListActivityAdd";
            this.btnListActivityAdd.Size = new System.Drawing.Size(75, 23);
            this.btnListActivityAdd.TabIndex = 14;
            this.btnListActivityAdd.Text = "Add";
            this.btnListActivityAdd.UseVisualStyleBackColor = true;
            this.btnListActivityAdd.Click += new System.EventHandler(this.btnListActivityAdd_Click);
            // 
            // txtListActivityID
            // 
            this.txtListActivityID.Location = new System.Drawing.Point(342, 234);
            this.txtListActivityID.Name = "txtListActivityID";
            this.txtListActivityID.Size = new System.Drawing.Size(100, 20);
            this.txtListActivityID.TabIndex = 13;
            // 
            // lblListActivityID
            // 
            this.lblListActivityID.AutoSize = true;
            this.lblListActivityID.Location = new System.Drawing.Point(339, 213);
            this.lblListActivityID.Name = "lblListActivityID";
            this.lblListActivityID.Size = new System.Drawing.Size(21, 13);
            this.lblListActivityID.TabIndex = 12;
            this.lblListActivityID.Text = "ID:";
            // 
            // removeActivity
            // 
            this.removeActivity.AutoSize = true;
            this.removeActivity.Location = new System.Drawing.Point(339, 192);
            this.removeActivity.Name = "removeActivity";
            this.removeActivity.Size = new System.Drawing.Size(86, 13);
            this.removeActivity.TabIndex = 11;
            this.removeActivity.Text = "Remove activity:";
            // 
            // lblListActivityStartDateTime
            // 
            this.lblListActivityStartDateTime.AutoSize = true;
            this.lblListActivityStartDateTime.Location = new System.Drawing.Point(339, 83);
            this.lblListActivityStartDateTime.Name = "lblListActivityStartDateTime";
            this.lblListActivityStartDateTime.Size = new System.Drawing.Size(89, 13);
            this.lblListActivityStartDateTime.TabIndex = 9;
            this.lblListActivityStartDateTime.Text = "Start Day + Time:";
            // 
            // lblListActivityName
            // 
            this.lblListActivityName.AutoSize = true;
            this.lblListActivityName.Location = new System.Drawing.Point(338, 41);
            this.lblListActivityName.Name = "lblListActivityName";
            this.lblListActivityName.Size = new System.Drawing.Size(38, 13);
            this.lblListActivityName.TabIndex = 8;
            this.lblListActivityName.Text = "Name:";
            // 
            // addActivity
            // 
            this.addActivity.AutoSize = true;
            this.addActivity.Location = new System.Drawing.Point(338, 18);
            this.addActivity.Name = "addActivity";
            this.addActivity.Size = new System.Drawing.Size(65, 13);
            this.addActivity.TabIndex = 7;
            this.addActivity.Text = "Add activity:";
            // 
            // txtListActivityName
            // 
            this.txtListActivityName.Location = new System.Drawing.Point(341, 60);
            this.txtListActivityName.Name = "txtListActivityName";
            this.txtListActivityName.Size = new System.Drawing.Size(100, 20);
            this.txtListActivityName.TabIndex = 6;
            // 
            // listViewListOfActivities
            // 
            this.listViewListOfActivities.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ListOfActivitiesActivityID,
            this.ListOfActivitiesActivityStartDateTime,
            this.ListOfActivitiesActivityEndDateTime,
            this.ListOfActivitiesActivityName});
            this.listViewListOfActivities.HideSelection = false;
            this.listViewListOfActivities.Location = new System.Drawing.Point(18, 34);
            this.listViewListOfActivities.Margin = new System.Windows.Forms.Padding(2);
            this.listViewListOfActivities.Name = "listViewListOfActivities";
            this.listViewListOfActivities.Size = new System.Drawing.Size(307, 426);
            this.listViewListOfActivities.TabIndex = 5;
            this.listViewListOfActivities.UseCompatibleStateImageBehavior = false;
            // 
            // ListOfActivitiesActivityID
            // 
            this.ListOfActivitiesActivityID.Text = "activityID";
            this.ListOfActivitiesActivityID.Width = 70;
            // 
            // ListOfActivitiesActivityStartDateTime
            // 
            this.ListOfActivitiesActivityStartDateTime.Text = "activityStartDateTime";
            this.ListOfActivitiesActivityStartDateTime.Width = 70;
            // 
            // ListOfActivitiesActivityEndDateTime
            // 
            this.ListOfActivitiesActivityEndDateTime.Text = "activityEndDateTime";
            this.ListOfActivitiesActivityEndDateTime.Width = 70;
            // 
            // ListOfActivitiesActivityName
            // 
            this.ListOfActivitiesActivityName.Text = "activityName";
            this.ListOfActivitiesActivityName.Width = 100;
            // 
            // activityListOfActivitiesPictureBox
            // 
            this.activityListOfActivitiesPictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.activityListOfActivitiesPictureBox.InitialImage = null;
            this.activityListOfActivitiesPictureBox.Location = new System.Drawing.Point(794, 1);
            this.activityListOfActivitiesPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.activityListOfActivitiesPictureBox.Name = "activityListOfActivitiesPictureBox";
            this.activityListOfActivitiesPictureBox.Size = new System.Drawing.Size(94, 80);
            this.activityListOfActivitiesPictureBox.TabIndex = 0;
            this.activityListOfActivitiesPictureBox.TabStop = false;
            // 
            // lblListOfActivities
            // 
            this.lblListOfActivities.AutoSize = true;
            this.lblListOfActivities.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListOfActivities.Location = new System.Drawing.Point(7, 6);
            this.lblListOfActivities.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblListOfActivities.Name = "lblListOfActivities";
            this.lblListOfActivities.Size = new System.Drawing.Size(176, 29);
            this.lblListOfActivities.TabIndex = 3;
            this.lblListOfActivities.Text = "List of Activities";
            // 
            // pnlActivityParticipants
            // 
            this.pnlActivityParticipants.Controls.Add(this.buttonRemoveParticipant);
            this.pnlActivityParticipants.Controls.Add(this.buttonAddParticipant);
            this.pnlActivityParticipants.Controls.Add(this.lblActivityParticipantsStudentID);
            this.pnlActivityParticipants.Controls.Add(this.lblActivityParticipantsParticipantID);
            this.pnlActivityParticipants.Controls.Add(this.txtAddStudentID);
            this.pnlActivityParticipants.Controls.Add(this.txtAddParticipantID);
            this.pnlActivityParticipants.Controls.Add(this.lbAddParticipants);
            this.pnlActivityParticipants.Controls.Add(this.lbActivitiesParticipantsSelectedActivity);
            this.pnlActivityParticipants.Controls.Add(this.listViewParticipantsActivities);
            this.pnlActivityParticipants.Controls.Add(this.listViewParticipants);
            this.pnlActivityParticipants.Controls.Add(this.activityParticipantPictureBox);
            this.pnlActivityParticipants.Controls.Add(this.lbActivityParticipant);
            this.pnlActivityParticipants.Location = new System.Drawing.Point(10, 31);
            this.pnlActivityParticipants.Margin = new System.Windows.Forms.Padding(2);
            this.pnlActivityParticipants.Name = "pnlActivityParticipants";
            this.pnlActivityParticipants.Size = new System.Drawing.Size(876, 488);
            this.pnlActivityParticipants.TabIndex = 19;
            // 
            // buttonRemoveParticipant
            // 
            this.buttonRemoveParticipant.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRemoveParticipant.Location = new System.Drawing.Point(446, 253);
            this.buttonRemoveParticipant.Name = "buttonRemoveParticipant";
            this.buttonRemoveParticipant.Size = new System.Drawing.Size(75, 40);
            this.buttonRemoveParticipant.TabIndex = 16;
            this.buttonRemoveParticipant.Text = "Remove";
            this.buttonRemoveParticipant.UseVisualStyleBackColor = true;
            this.buttonRemoveParticipant.Click += new System.EventHandler(this.buttonRemoveParticipant_Click);
            // 
            // buttonAddParticipant
            // 
            this.buttonAddParticipant.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddParticipant.Location = new System.Drawing.Point(684, 371);
            this.buttonAddParticipant.Name = "buttonAddParticipant";
            this.buttonAddParticipant.Size = new System.Drawing.Size(52, 40);
            this.buttonAddParticipant.TabIndex = 15;
            this.buttonAddParticipant.Text = "Add";
            this.buttonAddParticipant.UseVisualStyleBackColor = true;
            this.buttonAddParticipant.Click += new System.EventHandler(this.buttonAddParticipant_Click);
            // 
            // lblActivityParticipantsStudentID
            // 
            this.lblActivityParticipantsStudentID.AutoSize = true;
            this.lblActivityParticipantsStudentID.Location = new System.Drawing.Point(621, 349);
            this.lblActivityParticipantsStudentID.Name = "lblActivityParticipantsStudentID";
            this.lblActivityParticipantsStudentID.Size = new System.Drawing.Size(61, 13);
            this.lblActivityParticipantsStudentID.TabIndex = 13;
            this.lblActivityParticipantsStudentID.Text = "Student ID:";
            // 
            // lblActivityParticipantsParticipantID
            // 
            this.lblActivityParticipantsParticipantID.AutoSize = true;
            this.lblActivityParticipantsParticipantID.Location = new System.Drawing.Point(621, 319);
            this.lblActivityParticipantsParticipantID.Name = "lblActivityParticipantsParticipantID";
            this.lblActivityParticipantsParticipantID.Size = new System.Drawing.Size(60, 26);
            this.lblActivityParticipantsParticipantID.TabIndex = 12;
            this.lblActivityParticipantsParticipantID.Text = "Participant \r\nID:";
            // 
            // txtAddStudentID
            // 
            this.txtAddStudentID.Location = new System.Drawing.Point(684, 342);
            this.txtAddStudentID.Name = "txtAddStudentID";
            this.txtAddStudentID.Size = new System.Drawing.Size(100, 20);
            this.txtAddStudentID.TabIndex = 10;
            // 
            // txtAddParticipantID
            // 
            this.txtAddParticipantID.Location = new System.Drawing.Point(684, 316);
            this.txtAddParticipantID.Name = "txtAddParticipantID";
            this.txtAddParticipantID.Size = new System.Drawing.Size(100, 20);
            this.txtAddParticipantID.TabIndex = 9;
            // 
            // lbAddParticipants
            // 
            this.lbAddParticipants.AutoSize = true;
            this.lbAddParticipants.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAddParticipants.Location = new System.Drawing.Point(635, 290);
            this.lbAddParticipants.Name = "lbAddParticipants";
            this.lbAddParticipants.Size = new System.Drawing.Size(106, 18);
            this.lbAddParticipants.TabIndex = 8;
            this.lbAddParticipants.Text = "Add Participant";
            // 
            // lbActivitiesParticipantsSelectedActivity
            // 
            this.lbActivitiesParticipantsSelectedActivity.AutoSize = true;
            this.lbActivitiesParticipantsSelectedActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbActivitiesParticipantsSelectedActivity.Location = new System.Drawing.Point(363, 23);
            this.lbActivitiesParticipantsSelectedActivity.Name = "lbActivitiesParticipantsSelectedActivity";
            this.lbActivitiesParticipantsSelectedActivity.Size = new System.Drawing.Size(198, 16);
            this.lbActivitiesParticipantsSelectedActivity.TabIndex = 7;
            this.lbActivitiesParticipantsSelectedActivity.Text = "Participants for selected activity:";
            // 
            // listViewParticipantsActivities
            // 
            this.listViewParticipantsActivities.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.activityParticipantsActivitiesActivityID,
            this.activityParticipantsActivitiesActivityStartDate,
            this.activityParticipantsActivitiesActivityEndDate,
            this.activityParticipantsActivitiesActivityName});
            this.listViewParticipantsActivities.HideSelection = false;
            this.listViewParticipantsActivities.Location = new System.Drawing.Point(6, 44);
            this.listViewParticipantsActivities.Margin = new System.Windows.Forms.Padding(2);
            this.listViewParticipantsActivities.Name = "listViewParticipantsActivities";
            this.listViewParticipantsActivities.Size = new System.Drawing.Size(333, 193);
            this.listViewParticipantsActivities.TabIndex = 6;
            this.listViewParticipantsActivities.UseCompatibleStateImageBehavior = false;
            this.listViewParticipantsActivities.ItemActivate += new System.EventHandler(this.listViewParticipantsActivities_ItemActivate);
            // 
            // activityParticipantsActivitiesActivityID
            // 
            this.activityParticipantsActivitiesActivityID.Text = "Activity ID";
            this.activityParticipantsActivitiesActivityID.Width = 80;
            // 
            // activityParticipantsActivitiesActivityStartDate
            // 
            this.activityParticipantsActivitiesActivityStartDate.Text = "Start Date";
            // 
            // activityParticipantsActivitiesActivityEndDate
            // 
            this.activityParticipantsActivitiesActivityEndDate.Text = "End Date";
            // 
            // activityParticipantsActivitiesActivityName
            // 
            this.activityParticipantsActivitiesActivityName.Text = "Activity Name";
            this.activityParticipantsActivitiesActivityName.Width = 80;
            // 
            // listViewParticipants
            // 
            this.listViewParticipants.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.activityParticipantID,
            this.activityParticipantsStudentID,
            this.activityParticipantsActivityID,
            this.activityParticipantName});
            this.listViewParticipants.HideSelection = false;
            this.listViewParticipants.Location = new System.Drawing.Point(365, 44);
            this.listViewParticipants.Margin = new System.Windows.Forms.Padding(2);
            this.listViewParticipants.Name = "listViewParticipants";
            this.listViewParticipants.Size = new System.Drawing.Size(254, 193);
            this.listViewParticipants.TabIndex = 5;
            this.listViewParticipants.UseCompatibleStateImageBehavior = false;
            // 
            // activityParticipantID
            // 
            this.activityParticipantID.Text = "Participant ID";
            this.activityParticipantID.Width = 80;
            // 
            // activityParticipantsStudentID
            // 
            this.activityParticipantsStudentID.Text = "Student ID";
            // 
            // activityParticipantsActivityID
            // 
            this.activityParticipantsActivityID.Text = "Activity ID";
            this.activityParticipantsActivityID.Width = 80;
            // 
            // activityParticipantName
            // 
            this.activityParticipantName.Text = "Participant Name";
            this.activityParticipantName.Width = 80;
            // 
            // activityParticipantPictureBox
            // 
            this.activityParticipantPictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.activityParticipantPictureBox.InitialImage = null;
            this.activityParticipantPictureBox.Location = new System.Drawing.Point(711, 12);
            this.activityParticipantPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.activityParticipantPictureBox.Name = "activityParticipantPictureBox";
            this.activityParticipantPictureBox.Size = new System.Drawing.Size(132, 119);
            this.activityParticipantPictureBox.TabIndex = 0;
            this.activityParticipantPictureBox.TabStop = false;
            // 
            // lbActivityParticipant
            // 
            this.lbActivityParticipant.AutoSize = true;
            this.lbActivityParticipant.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbActivityParticipant.Location = new System.Drawing.Point(3, 7);
            this.lbActivityParticipant.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbActivityParticipant.Name = "lbActivityParticipant";
            this.lbActivityParticipant.Size = new System.Drawing.Size(217, 29);
            this.lbActivityParticipant.TabIndex = 3;
            this.lbActivityParticipant.Text = "Activity Participants";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Activity ID";
            this.columnHeader7.Width = 80;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Activity ID";
            this.columnHeader8.Width = 80;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Student ID";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Activity ID";
            this.columnHeader10.Width = 80;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Participant ID";
            this.columnHeader11.Width = 80;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Participant ID";
            this.columnHeader12.Width = 80;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Participant ID";
            this.columnHeader13.Width = 80;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Participant ID";
            this.columnHeader14.Width = 80;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Participant ID";
            this.columnHeader15.Width = 80;
            // 
            // pnlActivitySupervisors
            // 
            this.pnlActivitySupervisors.Controls.Add(this.activitySupervisorsHeaderLabel);
            this.pnlActivitySupervisors.Controls.Add(this.activitySupervisorsActivitiesHeaderLabel);
            this.pnlActivitySupervisors.Controls.Add(this.teacherIDLabel);
            this.pnlActivitySupervisors.Controls.Add(this.supervisorTeacherIdTextBox);
            this.pnlActivitySupervisors.Controls.Add(this.supervisorIdTextBox);
            this.pnlActivitySupervisors.Controls.Add(this.addNewSupervisorLabel);
            this.pnlActivitySupervisors.Controls.Add(this.supervisorIdLabel);
            this.pnlActivitySupervisors.Controls.Add(this.supervisorDeleteButton);
            this.pnlActivitySupervisors.Controls.Add(this.addSupervisorButton);
            this.pnlActivitySupervisors.Controls.Add(this.selectedActivitySupervisorsListView);
            this.pnlActivitySupervisors.Controls.Add(this.activitySupervisorsListView);
            this.pnlActivitySupervisors.Controls.Add(this.activitySupervisorPictureBox);
            this.pnlActivitySupervisors.Controls.Add(this.activitySupervisorLabel);
            this.pnlActivitySupervisors.Location = new System.Drawing.Point(7, 28);
            this.pnlActivitySupervisors.Margin = new System.Windows.Forms.Padding(2);
            this.pnlActivitySupervisors.Name = "pnlActivitySupervisors";
            this.pnlActivitySupervisors.Size = new System.Drawing.Size(881, 491);
            this.pnlActivitySupervisors.TabIndex = 20;
            // 
            // activitySupervisorsHeaderLabel
            // 
            this.activitySupervisorsHeaderLabel.AutoSize = true;
            this.activitySupervisorsHeaderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activitySupervisorsHeaderLabel.Location = new System.Drawing.Point(409, 42);
            this.activitySupervisorsHeaderLabel.Name = "activitySupervisorsHeaderLabel";
            this.activitySupervisorsHeaderLabel.Size = new System.Drawing.Size(227, 20);
            this.activitySupervisorsHeaderLabel.TabIndex = 15;
            this.activitySupervisorsHeaderLabel.Text = "Supervisors by selected activity";
            // 
            // activitySupervisorsActivitiesHeaderLabel
            // 
            this.activitySupervisorsActivitiesHeaderLabel.AutoSize = true;
            this.activitySupervisorsActivitiesHeaderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activitySupervisorsActivitiesHeaderLabel.Location = new System.Drawing.Point(8, 41);
            this.activitySupervisorsActivitiesHeaderLabel.Name = "activitySupervisorsActivitiesHeaderLabel";
            this.activitySupervisorsActivitiesHeaderLabel.Size = new System.Drawing.Size(71, 20);
            this.activitySupervisorsActivitiesHeaderLabel.TabIndex = 14;
            this.activitySupervisorsActivitiesHeaderLabel.Text = "Activities";
            // 
            // teacherIDLabel
            // 
            this.teacherIDLabel.AutoSize = true;
            this.teacherIDLabel.Location = new System.Drawing.Point(103, 330);
            this.teacherIDLabel.Name = "teacherIDLabel";
            this.teacherIDLabel.Size = new System.Drawing.Size(64, 13);
            this.teacherIDLabel.TabIndex = 13;
            this.teacherIDLabel.Text = "Teacher ID:";
            // 
            // supervisorTeacherIdTextBox
            // 
            this.supervisorTeacherIdTextBox.Location = new System.Drawing.Point(183, 327);
            this.supervisorTeacherIdTextBox.Name = "supervisorTeacherIdTextBox";
            this.supervisorTeacherIdTextBox.Size = new System.Drawing.Size(47, 20);
            this.supervisorTeacherIdTextBox.TabIndex = 12;
            // 
            // supervisorIdTextBox
            // 
            this.supervisorIdTextBox.Location = new System.Drawing.Point(183, 301);
            this.supervisorIdTextBox.Name = "supervisorIdTextBox";
            this.supervisorIdTextBox.Size = new System.Drawing.Size(47, 20);
            this.supervisorIdTextBox.TabIndex = 11;
            // 
            // addNewSupervisorLabel
            // 
            this.addNewSupervisorLabel.AutoSize = true;
            this.addNewSupervisorLabel.Location = new System.Drawing.Point(9, 277);
            this.addNewSupervisorLabel.Name = "addNewSupervisorLabel";
            this.addNewSupervisorLabel.Size = new System.Drawing.Size(221, 13);
            this.addNewSupervisorLabel.TabIndex = 10;
            this.addNewSupervisorLabel.Text = "Add a new supervisor to the selected activity:";
            // 
            // supervisorIdLabel
            // 
            this.supervisorIdLabel.AutoSize = true;
            this.supervisorIdLabel.Location = new System.Drawing.Point(102, 304);
            this.supervisorIdLabel.Name = "supervisorIdLabel";
            this.supervisorIdLabel.Size = new System.Drawing.Size(74, 13);
            this.supervisorIdLabel.TabIndex = 9;
            this.supervisorIdLabel.Text = "Supervisor ID:";
            // 
            // supervisorDeleteButton
            // 
            this.supervisorDeleteButton.Location = new System.Drawing.Point(407, 325);
            this.supervisorDeleteButton.Name = "supervisorDeleteButton";
            this.supervisorDeleteButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.supervisorDeleteButton.Size = new System.Drawing.Size(75, 23);
            this.supervisorDeleteButton.TabIndex = 8;
            this.supervisorDeleteButton.Text = "Delete";
            this.supervisorDeleteButton.UseVisualStyleBackColor = true;
            this.supervisorDeleteButton.Click += new System.EventHandler(this.supervisorDeleteButton_Click);
            // 
            // addSupervisorButton
            // 
            this.addSupervisorButton.Location = new System.Drawing.Point(247, 325);
            this.addSupervisorButton.Name = "addSupervisorButton";
            this.addSupervisorButton.Size = new System.Drawing.Size(75, 23);
            this.addSupervisorButton.TabIndex = 7;
            this.addSupervisorButton.Text = "Add";
            this.addSupervisorButton.UseVisualStyleBackColor = true;
            this.addSupervisorButton.Click += new System.EventHandler(this.addSupervisorButton_Click);
            // 
            // selectedActivitySupervisorsListView
            // 
            this.selectedActivitySupervisorsListView.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.selectedActivitySupervisorsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.activitySupervisorsSupervisorId,
            this.activitySupervisorsTeacherId,
            this.activitySupervisorsSelectedActivityId,
            this.activitySupervisorsSupervisorName});
            this.selectedActivitySupervisorsListView.Cursor = System.Windows.Forms.Cursors.Default;
            this.selectedActivitySupervisorsListView.FullRowSelect = true;
            this.selectedActivitySupervisorsListView.HideSelection = false;
            this.selectedActivitySupervisorsListView.HotTracking = true;
            this.selectedActivitySupervisorsListView.HoverSelection = true;
            this.selectedActivitySupervisorsListView.Location = new System.Drawing.Point(413, 64);
            this.selectedActivitySupervisorsListView.Margin = new System.Windows.Forms.Padding(2);
            this.selectedActivitySupervisorsListView.Name = "selectedActivitySupervisorsListView";
            this.selectedActivitySupervisorsListView.Size = new System.Drawing.Size(259, 212);
            this.selectedActivitySupervisorsListView.TabIndex = 6;
            this.selectedActivitySupervisorsListView.UseCompatibleStateImageBehavior = false;
            // 
            // activitySupervisorsSupervisorId
            // 
            this.activitySupervisorsSupervisorId.Text = "supervisorID";
            // 
            // activitySupervisorsTeacherId
            // 
            this.activitySupervisorsTeacherId.Text = "teacherID";
            this.activitySupervisorsTeacherId.Width = 100;
            // 
            // activitySupervisorsSelectedActivityId
            // 
            this.activitySupervisorsSelectedActivityId.Text = "activityID";
            this.activitySupervisorsSelectedActivityId.Width = 120;
            // 
            // activitySupervisorsSupervisorName
            // 
            this.activitySupervisorsSupervisorName.Text = "supervisor name";
            // 
            // activitySupervisorsListView
            // 
            this.activitySupervisorsListView.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.activitySupervisorsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.activitySupervisorsActivityID,
            this.activitySupervisorActivityStartDate,
            this.activitySupervisorsActivityEndDate,
            this.activitySupervisorActivityName});
            this.activitySupervisorsListView.FullRowSelect = true;
            this.activitySupervisorsListView.HideSelection = false;
            this.activitySupervisorsListView.HotTracking = true;
            this.activitySupervisorsListView.HoverSelection = true;
            this.activitySupervisorsListView.Location = new System.Drawing.Point(8, 64);
            this.activitySupervisorsListView.Margin = new System.Windows.Forms.Padding(2);
            this.activitySupervisorsListView.Name = "activitySupervisorsListView";
            this.activitySupervisorsListView.Size = new System.Drawing.Size(388, 212);
            this.activitySupervisorsListView.TabIndex = 5;
            this.activitySupervisorsListView.UseCompatibleStateImageBehavior = false;
            this.activitySupervisorsListView.ItemActivate += new System.EventHandler(this.activitySupervisorsListView_ItemActivate);
            // 
            // activitySupervisorsActivityID
            // 
            this.activitySupervisorsActivityID.Text = "activityID";
            // 
            // activitySupervisorActivityStartDate
            // 
            this.activitySupervisorActivityStartDate.Text = "start date";
            this.activitySupervisorActivityStartDate.Width = 120;
            // 
            // activitySupervisorsActivityEndDate
            // 
            this.activitySupervisorsActivityEndDate.Text = "end date";
            this.activitySupervisorsActivityEndDate.Width = 120;
            // 
            // activitySupervisorActivityName
            // 
            this.activitySupervisorActivityName.Text = "activity name";
            this.activitySupervisorActivityName.Width = 100;
            // 
            // activitySupervisorPictureBox
            // 
            this.activitySupervisorPictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.activitySupervisorPictureBox.InitialImage = null;
            this.activitySupervisorPictureBox.Location = new System.Drawing.Point(722, 13);
            this.activitySupervisorPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.activitySupervisorPictureBox.Name = "activitySupervisorPictureBox";
            this.activitySupervisorPictureBox.Size = new System.Drawing.Size(124, 121);
            this.activitySupervisorPictureBox.TabIndex = 0;
            this.activitySupervisorPictureBox.TabStop = false;
            // 
            // activitySupervisorLabel
            // 
            this.activitySupervisorLabel.AutoSize = true;
            this.activitySupervisorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activitySupervisorLabel.Location = new System.Drawing.Point(7, 6);
            this.activitySupervisorLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.activitySupervisorLabel.Name = "activitySupervisorLabel";
            this.activitySupervisorLabel.Size = new System.Drawing.Size(220, 29);
            this.activitySupervisorLabel.TabIndex = 3;
            this.activitySupervisorLabel.Text = "Activity Supervisors";
            // 
            // lblRecoverPasswordResetMessage
            // 
            this.lblRecoverPasswordResetMessage.AutoSize = true;
            this.lblRecoverPasswordResetMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoverPasswordResetMessage.Location = new System.Drawing.Point(43, 362);
            this.lblRecoverPasswordResetMessage.Name = "lblRecoverPasswordResetMessage";
            this.lblRecoverPasswordResetMessage.Size = new System.Drawing.Size(0, 20);
            this.lblRecoverPasswordResetMessage.TabIndex = 16;
            // 
            // buttonRecoverPasswordReset
            // 
            this.buttonRecoverPasswordReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRecoverPasswordReset.Location = new System.Drawing.Point(100, 411);
            this.buttonRecoverPasswordReset.Name = "buttonRecoverPasswordReset";
            this.buttonRecoverPasswordReset.Size = new System.Drawing.Size(109, 32);
            this.buttonRecoverPasswordReset.TabIndex = 17;
            this.buttonRecoverPasswordReset.Text = "Reset fields";
            this.buttonRecoverPasswordReset.UseVisualStyleBackColor = true;
            this.buttonRecoverPasswordReset.Click += new System.EventHandler(this.buttonRecoverPasswordReset_Click);
            // 
            // pnlRecoverPassword
            // 
            this.pnlRecoverPassword.Controls.Add(this.linkLabelBackToLogin);
            this.pnlRecoverPassword.Controls.Add(this.buttonRecoverPasswordReset);
            this.pnlRecoverPassword.Controls.Add(this.lblRecoverPasswordResetMessage);
            this.pnlRecoverPassword.Controls.Add(this.buttonRecoverPasswordSetNewPassword);
            this.pnlRecoverPassword.Controls.Add(this.txtRecoverPasswordNewPassword);
            this.pnlRecoverPassword.Controls.Add(this.lblRecoverPasswordNewPassword);
            this.pnlRecoverPassword.Controls.Add(this.buttonRecoverPasswordCheckAnswer);
            this.pnlRecoverPassword.Controls.Add(this.buttonRecoverPasswordGetSecretQuestion);
            this.pnlRecoverPassword.Controls.Add(this.txtRecoverPasswordAnswer);
            this.pnlRecoverPassword.Controls.Add(this.txtRecoverPasswordUsername);
            this.pnlRecoverPassword.Controls.Add(this.lblRecoverPasswordSecretQuestion);
            this.pnlRecoverPassword.Controls.Add(this.lblRecoverPasswordUsername);
            this.pnlRecoverPassword.Controls.Add(this.listViewRecoverPassword);
            this.pnlRecoverPassword.Controls.Add(this.lblRecoverPassword);
            this.pnlRecoverPassword.Location = new System.Drawing.Point(0, 0);
            this.pnlRecoverPassword.Name = "pnlRecoverPassword";
            this.pnlRecoverPassword.Size = new System.Drawing.Size(894, 527);
            this.pnlRecoverPassword.TabIndex = 33;
            // 
            // buttonRecoverPasswordSetNewPassword
            // 
            this.buttonRecoverPasswordSetNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRecoverPasswordSetNewPassword.Location = new System.Drawing.Point(190, 286);
            this.buttonRecoverPasswordSetNewPassword.Name = "buttonRecoverPasswordSetNewPassword";
            this.buttonRecoverPasswordSetNewPassword.Size = new System.Drawing.Size(68, 32);
            this.buttonRecoverPasswordSetNewPassword.TabIndex = 15;
            this.buttonRecoverPasswordSetNewPassword.Text = "Change";
            this.buttonRecoverPasswordSetNewPassword.UseVisualStyleBackColor = true;
            this.buttonRecoverPasswordSetNewPassword.Visible = false;
            this.buttonRecoverPasswordSetNewPassword.Click += new System.EventHandler(this.buttonRecoverPasswordSetNewPassword_Click);
            // 
            // txtRecoverPasswordNewPassword
            // 
            this.txtRecoverPasswordNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRecoverPasswordNewPassword.Location = new System.Drawing.Point(43, 289);
            this.txtRecoverPasswordNewPassword.Name = "txtRecoverPasswordNewPassword";
            this.txtRecoverPasswordNewPassword.Size = new System.Drawing.Size(124, 22);
            this.txtRecoverPasswordNewPassword.TabIndex = 14;
            this.txtRecoverPasswordNewPassword.Visible = false;
            // 
            // lblRecoverPasswordNewPassword
            // 
            this.lblRecoverPasswordNewPassword.AutoSize = true;
            this.lblRecoverPasswordNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoverPasswordNewPassword.Location = new System.Drawing.Point(42, 261);
            this.lblRecoverPasswordNewPassword.Name = "lblRecoverPasswordNewPassword";
            this.lblRecoverPasswordNewPassword.Size = new System.Drawing.Size(0, 20);
            this.lblRecoverPasswordNewPassword.TabIndex = 13;
            // 
            // buttonRecoverPasswordCheckAnswer
            // 
            this.buttonRecoverPasswordCheckAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRecoverPasswordCheckAnswer.Location = new System.Drawing.Point(228, 193);
            this.buttonRecoverPasswordCheckAnswer.Name = "buttonRecoverPasswordCheckAnswer";
            this.buttonRecoverPasswordCheckAnswer.Size = new System.Drawing.Size(48, 32);
            this.buttonRecoverPasswordCheckAnswer.TabIndex = 12;
            this.buttonRecoverPasswordCheckAnswer.Text = "Next";
            this.buttonRecoverPasswordCheckAnswer.UseVisualStyleBackColor = true;
            this.buttonRecoverPasswordCheckAnswer.Visible = false;
            this.buttonRecoverPasswordCheckAnswer.Click += new System.EventHandler(this.buttonRecoverPasswordCheckAnswer_Click);
            // 
            // buttonRecoverPasswordGetSecretQuestion
            // 
            this.buttonRecoverPasswordGetSecretQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRecoverPasswordGetSecretQuestion.Location = new System.Drawing.Point(190, 109);
            this.buttonRecoverPasswordGetSecretQuestion.Name = "buttonRecoverPasswordGetSecretQuestion";
            this.buttonRecoverPasswordGetSecretQuestion.Size = new System.Drawing.Size(48, 32);
            this.buttonRecoverPasswordGetSecretQuestion.TabIndex = 11;
            this.buttonRecoverPasswordGetSecretQuestion.Text = "Next";
            this.buttonRecoverPasswordGetSecretQuestion.UseVisualStyleBackColor = true;
            this.buttonRecoverPasswordGetSecretQuestion.Click += new System.EventHandler(this.buttonRecoverPasswordGetSecretQuestion_Click);
            // 
            // txtRecoverPasswordAnswer
            // 
            this.txtRecoverPasswordAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRecoverPasswordAnswer.Location = new System.Drawing.Point(43, 200);
            this.txtRecoverPasswordAnswer.Name = "txtRecoverPasswordAnswer";
            this.txtRecoverPasswordAnswer.Size = new System.Drawing.Size(166, 22);
            this.txtRecoverPasswordAnswer.TabIndex = 10;
            this.txtRecoverPasswordAnswer.Visible = false;
            // 
            // txtRecoverPasswordUsername
            // 
            this.txtRecoverPasswordUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRecoverPasswordUsername.Location = new System.Drawing.Point(43, 119);
            this.txtRecoverPasswordUsername.Name = "txtRecoverPasswordUsername";
            this.txtRecoverPasswordUsername.Size = new System.Drawing.Size(124, 22);
            this.txtRecoverPasswordUsername.TabIndex = 9;
            // 
            // lblRecoverPasswordSecretQuestion
            // 
            this.lblRecoverPasswordSecretQuestion.AutoSize = true;
            this.lblRecoverPasswordSecretQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoverPasswordSecretQuestion.Location = new System.Drawing.Point(43, 160);
            this.lblRecoverPasswordSecretQuestion.Name = "lblRecoverPasswordSecretQuestion";
            this.lblRecoverPasswordSecretQuestion.Size = new System.Drawing.Size(0, 20);
            this.lblRecoverPasswordSecretQuestion.TabIndex = 8;
            // 
            // lblRecoverPasswordUsername
            // 
            this.lblRecoverPasswordUsername.AutoSize = true;
            this.lblRecoverPasswordUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoverPasswordUsername.Location = new System.Drawing.Point(43, 92);
            this.lblRecoverPasswordUsername.Name = "lblRecoverPasswordUsername";
            this.lblRecoverPasswordUsername.Size = new System.Drawing.Size(87, 20);
            this.lblRecoverPasswordUsername.TabIndex = 7;
            this.lblRecoverPasswordUsername.Text = "Username:";
            // 
            // listViewRecoverPassword
            // 
            this.listViewRecoverPassword.HideSelection = false;
            this.listViewRecoverPassword.Location = new System.Drawing.Point(21, 61);
            this.listViewRecoverPassword.Margin = new System.Windows.Forms.Padding(2);
            this.listViewRecoverPassword.Name = "listViewRecoverPassword";
            this.listViewRecoverPassword.Size = new System.Drawing.Size(294, 399);
            this.listViewRecoverPassword.TabIndex = 6;
            this.listViewRecoverPassword.UseCompatibleStateImageBehavior = false;
            // 
            // lblRecoverPassword
            // 
            this.lblRecoverPassword.AutoSize = true;
            this.lblRecoverPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoverPassword.Location = new System.Drawing.Point(16, 21);
            this.lblRecoverPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRecoverPassword.Name = "lblRecoverPassword";
            this.lblRecoverPassword.Size = new System.Drawing.Size(216, 29);
            this.lblRecoverPassword.TabIndex = 4;
            this.lblRecoverPassword.Text = "Recover Password";
            // 
            // pnlLoginPanel
            // 
            this.pnlLoginPanel.Controls.Add(this.buttonRegisterUser);
            this.pnlLoginPanel.Controls.Add(this.btnRecoverPasswordLoginPanel);
            this.pnlLoginPanel.Controls.Add(this.btnLoginPanel);
            this.pnlLoginPanel.Controls.Add(this.txtPasswordLoginPanel);
            this.pnlLoginPanel.Controls.Add(this.txtUsernameLoginPanel);
            this.pnlLoginPanel.Controls.Add(this.passwordLoginPanel);
            this.pnlLoginPanel.Controls.Add(this.usernameLoginPanel);
            this.pnlLoginPanel.Controls.Add(this.loginPanelPictureBox);
            this.pnlLoginPanel.Controls.Add(this.loginPanelLabel);
            this.pnlLoginPanel.Location = new System.Drawing.Point(10, 0);
            this.pnlLoginPanel.Margin = new System.Windows.Forms.Padding(2);
            this.pnlLoginPanel.Name = "pnlLoginPanel";
            this.pnlLoginPanel.Size = new System.Drawing.Size(881, 512);
            this.pnlLoginPanel.TabIndex = 34;
            // 
            // buttonRegisterUser
            // 
            this.buttonRegisterUser.Location = new System.Drawing.Point(330, 111);
            this.buttonRegisterUser.Name = "buttonRegisterUser";
            this.buttonRegisterUser.Size = new System.Drawing.Size(117, 29);
            this.buttonRegisterUser.TabIndex = 10;
            this.buttonRegisterUser.Text = "Register new user";
            this.buttonRegisterUser.UseVisualStyleBackColor = true;
            this.buttonRegisterUser.Click += new System.EventHandler(this.buttonRegisterUser_Click);
            // 
            // btnRecoverPasswordLoginPanel
            // 
            this.btnRecoverPasswordLoginPanel.Location = new System.Drawing.Point(330, 161);
            this.btnRecoverPasswordLoginPanel.Name = "btnRecoverPasswordLoginPanel";
            this.btnRecoverPasswordLoginPanel.Size = new System.Drawing.Size(117, 30);
            this.btnRecoverPasswordLoginPanel.TabIndex = 9;
            this.btnRecoverPasswordLoginPanel.Text = "Recover password";
            this.btnRecoverPasswordLoginPanel.UseVisualStyleBackColor = true;
            this.btnRecoverPasswordLoginPanel.Click += new System.EventHandler(this.btnRecoverPasswordLoginPanel_Click);
            // 
            // btnLoginPanel
            // 
            this.btnLoginPanel.Location = new System.Drawing.Point(153, 207);
            this.btnLoginPanel.Name = "btnLoginPanel";
            this.btnLoginPanel.Size = new System.Drawing.Size(75, 23);
            this.btnLoginPanel.TabIndex = 8;
            this.btnLoginPanel.Text = "Login";
            this.btnLoginPanel.UseVisualStyleBackColor = true;
            this.btnLoginPanel.Click += new System.EventHandler(this.btnLoginPanel_Click);
            // 
            // txtPasswordLoginPanel
            // 
            this.txtPasswordLoginPanel.Location = new System.Drawing.Point(148, 158);
            this.txtPasswordLoginPanel.Name = "txtPasswordLoginPanel";
            this.txtPasswordLoginPanel.Size = new System.Drawing.Size(100, 20);
            this.txtPasswordLoginPanel.TabIndex = 7;
            // 
            // txtUsernameLoginPanel
            // 
            this.txtUsernameLoginPanel.Location = new System.Drawing.Point(148, 112);
            this.txtUsernameLoginPanel.Name = "txtUsernameLoginPanel";
            this.txtUsernameLoginPanel.Size = new System.Drawing.Size(100, 20);
            this.txtUsernameLoginPanel.TabIndex = 6;
            // 
            // passwordLoginPanel
            // 
            this.passwordLoginPanel.AutoSize = true;
            this.passwordLoginPanel.Location = new System.Drawing.Point(56, 161);
            this.passwordLoginPanel.Name = "passwordLoginPanel";
            this.passwordLoginPanel.Size = new System.Drawing.Size(56, 13);
            this.passwordLoginPanel.TabIndex = 5;
            this.passwordLoginPanel.Text = "Password:";
            // 
            // usernameLoginPanel
            // 
            this.usernameLoginPanel.AutoSize = true;
            this.usernameLoginPanel.Location = new System.Drawing.Point(56, 115);
            this.usernameLoginPanel.Name = "usernameLoginPanel";
            this.usernameLoginPanel.Size = new System.Drawing.Size(58, 13);
            this.usernameLoginPanel.TabIndex = 4;
            this.usernameLoginPanel.Text = "Username:";
            // 
            // loginPanelPictureBox
            // 
            this.loginPanelPictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.loginPanelPictureBox.InitialImage = null;
            this.loginPanelPictureBox.Location = new System.Drawing.Point(722, 13);
            this.loginPanelPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.loginPanelPictureBox.Name = "loginPanelPictureBox";
            this.loginPanelPictureBox.Size = new System.Drawing.Size(124, 121);
            this.loginPanelPictureBox.TabIndex = 0;
            this.loginPanelPictureBox.TabStop = false;
            // 
            // loginPanelLabel
            // 
            this.loginPanelLabel.AutoSize = true;
            this.loginPanelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginPanelLabel.Location = new System.Drawing.Point(7, 6);
            this.loginPanelLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.loginPanelLabel.Name = "loginPanelLabel";
            this.loginPanelLabel.Size = new System.Drawing.Size(73, 29);
            this.loginPanelLabel.TabIndex = 3;
            this.loginPanelLabel.Text = "Login";
            // 
            // pnlRegisterUser
            // 
            this.pnlRegisterUser.Controls.Add(this.registerUserLabel);
            this.pnlRegisterUser.Controls.Add(this.secretAnswerTextBox);
            this.pnlRegisterUser.Controls.Add(this.secretQuestionTextBox);
            this.pnlRegisterUser.Controls.Add(this.secretAnswerLabel);
            this.pnlRegisterUser.Controls.Add(this.secretQuestionLabel);
            this.pnlRegisterUser.Controls.Add(this.ToLoginFormLinkLabel);
            this.pnlRegisterUser.Controls.Add(this.licenceKeyLabel);
            this.pnlRegisterUser.Controls.Add(this.licenceKeyTextBox);
            this.pnlRegisterUser.Controls.Add(this.registerButton);
            this.pnlRegisterUser.Controls.Add(this.passwordRegisterTextBox);
            this.pnlRegisterUser.Controls.Add(this.usernameRegisterTextBox);
            this.pnlRegisterUser.Controls.Add(this.passwordRegisterLabel);
            this.pnlRegisterUser.Controls.Add(this.usernameRegisterLabel);
            this.pnlRegisterUser.Controls.Add(this.registerNewUserPictureBox);
            this.pnlRegisterUser.Location = new System.Drawing.Point(0, 0);
            this.pnlRegisterUser.Margin = new System.Windows.Forms.Padding(2);
            this.pnlRegisterUser.Name = "pnlRegisterUser";
            this.pnlRegisterUser.Size = new System.Drawing.Size(901, 535);
            this.pnlRegisterUser.TabIndex = 35;
            // 
            // secretAnswerTextBox
            // 
            this.secretAnswerTextBox.Location = new System.Drawing.Point(374, 275);
            this.secretAnswerTextBox.Name = "secretAnswerTextBox";
            this.secretAnswerTextBox.Size = new System.Drawing.Size(230, 20);
            this.secretAnswerTextBox.TabIndex = 15;
            // 
            // secretQuestionTextBox
            // 
            this.secretQuestionTextBox.Location = new System.Drawing.Point(374, 225);
            this.secretQuestionTextBox.Name = "secretQuestionTextBox";
            this.secretQuestionTextBox.Size = new System.Drawing.Size(230, 20);
            this.secretQuestionTextBox.TabIndex = 14;
            // 
            // secretAnswerLabel
            // 
            this.secretAnswerLabel.AutoSize = true;
            this.secretAnswerLabel.Location = new System.Drawing.Point(282, 278);
            this.secretAnswerLabel.Name = "secretAnswerLabel";
            this.secretAnswerLabel.Size = new System.Drawing.Size(79, 13);
            this.secretAnswerLabel.TabIndex = 13;
            this.secretAnswerLabel.Text = "Secret Answer:";
            // 
            // secretQuestionLabel
            // 
            this.secretQuestionLabel.AutoSize = true;
            this.secretQuestionLabel.Location = new System.Drawing.Point(282, 228);
            this.secretQuestionLabel.Name = "secretQuestionLabel";
            this.secretQuestionLabel.Size = new System.Drawing.Size(84, 13);
            this.secretQuestionLabel.TabIndex = 12;
            this.secretQuestionLabel.Text = "Secret question:";
            // 
            // ToLoginFormLinkLabel
            // 
            this.ToLoginFormLinkLabel.AutoSize = true;
            this.ToLoginFormLinkLabel.Location = new System.Drawing.Point(692, 416);
            this.ToLoginFormLinkLabel.Name = "ToLoginFormLinkLabel";
            this.ToLoginFormLinkLabel.Size = new System.Drawing.Size(132, 13);
            this.ToLoginFormLinkLabel.TabIndex = 11;
            this.ToLoginFormLinkLabel.TabStop = true;
            this.ToLoginFormLinkLabel.Text = "Already have an account?";
            this.ToLoginFormLinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ToLoginFormLinkLabel_LinkClicked);
            // 
            // licenceKeyLabel
            // 
            this.licenceKeyLabel.AutoSize = true;
            this.licenceKeyLabel.Location = new System.Drawing.Point(282, 343);
            this.licenceKeyLabel.Name = "licenceKeyLabel";
            this.licenceKeyLabel.Size = new System.Drawing.Size(68, 13);
            this.licenceKeyLabel.TabIndex = 10;
            this.licenceKeyLabel.Text = "Licence key:";
            // 
            // licenceKeyTextBox
            // 
            this.licenceKeyTextBox.Location = new System.Drawing.Point(374, 338);
            this.licenceKeyTextBox.Name = "licenceKeyTextBox";
            this.licenceKeyTextBox.Size = new System.Drawing.Size(230, 20);
            this.licenceKeyTextBox.TabIndex = 9;
            // 
            // registerButton
            // 
            this.registerButton.Location = new System.Drawing.Point(426, 410);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(75, 23);
            this.registerButton.TabIndex = 8;
            this.registerButton.Text = "Register";
            this.registerButton.UseVisualStyleBackColor = true;
            this.registerButton.Click += new System.EventHandler(this.registerButton_Click);
            // 
            // passwordRegisterTextBox
            // 
            this.passwordRegisterTextBox.Location = new System.Drawing.Point(374, 181);
            this.passwordRegisterTextBox.Name = "passwordRegisterTextBox";
            this.passwordRegisterTextBox.Size = new System.Drawing.Size(147, 20);
            this.passwordRegisterTextBox.TabIndex = 7;
            // 
            // usernameRegisterTextBox
            // 
            this.usernameRegisterTextBox.Location = new System.Drawing.Point(374, 135);
            this.usernameRegisterTextBox.Name = "usernameRegisterTextBox";
            this.usernameRegisterTextBox.Size = new System.Drawing.Size(147, 20);
            this.usernameRegisterTextBox.TabIndex = 6;
            // 
            // passwordRegisterLabel
            // 
            this.passwordRegisterLabel.AutoSize = true;
            this.passwordRegisterLabel.Location = new System.Drawing.Point(282, 184);
            this.passwordRegisterLabel.Name = "passwordRegisterLabel";
            this.passwordRegisterLabel.Size = new System.Drawing.Size(56, 13);
            this.passwordRegisterLabel.TabIndex = 5;
            this.passwordRegisterLabel.Text = "Password:";
            // 
            // usernameRegisterLabel
            // 
            this.usernameRegisterLabel.AutoSize = true;
            this.usernameRegisterLabel.Location = new System.Drawing.Point(282, 138);
            this.usernameRegisterLabel.Name = "usernameRegisterLabel";
            this.usernameRegisterLabel.Size = new System.Drawing.Size(58, 13);
            this.usernameRegisterLabel.TabIndex = 4;
            this.usernameRegisterLabel.Text = "Username:";
            // 
            // registerNewUserPictureBox
            // 
            this.registerNewUserPictureBox.Image = global::SomerenUI.Properties.Resources.someren;
            this.registerNewUserPictureBox.InitialImage = null;
            this.registerNewUserPictureBox.Location = new System.Drawing.Point(722, 13);
            this.registerNewUserPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.registerNewUserPictureBox.Name = "registerNewUserPictureBox";
            this.registerNewUserPictureBox.Size = new System.Drawing.Size(124, 121);
            this.registerNewUserPictureBox.TabIndex = 0;
            this.registerNewUserPictureBox.TabStop = false;
            // 
            // registerUserLabel
            // 
            this.registerUserLabel.AutoSize = true;
            this.registerUserLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registerUserLabel.Location = new System.Drawing.Point(7, 6);
            this.registerUserLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.registerUserLabel.Name = "registerUserLabel";
            this.registerUserLabel.Size = new System.Drawing.Size(208, 29);
            this.registerUserLabel.TabIndex = 3;
            this.registerUserLabel.Text = "Register new user";
            // 
            // linkLabelBackToLogin
            // 
            this.linkLabelBackToLogin.AutoSize = true;
            this.linkLabelBackToLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelBackToLogin.Location = new System.Drawing.Point(124, 476);
            this.linkLabelBackToLogin.Name = "linkLabelBackToLogin";
            this.linkLabelBackToLogin.Size = new System.Drawing.Size(85, 16);
            this.linkLabelBackToLogin.TabIndex = 18;
            this.linkLabelBackToLogin.TabStop = true;
            this.linkLabelBackToLogin.Text = "Back to login";
            this.linkLabelBackToLogin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBackToLogin_LinkClicked);
            // 
            // supervisorDaoBindingSource
            // 
            this.supervisorDaoBindingSource.DataSource = typeof(SomerenDAL.SupervisorDao);
            // 
            // supervisorDaoBindingSource1
            // 
            this.supervisorDaoBindingSource1.DataSource = typeof(SomerenDAL.SupervisorDao);
            // 
            // supervisorServiceBindingSource
            // 
            this.supervisorServiceBindingSource.DataSource = typeof(SomerenLogic.SupervisorService);
            // 
            // SomerenUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 532);
            this.Controls.Add(this.pnlActivitySupervisors);
            this.Controls.Add(this.pnlDrinksCash);
            this.Controls.Add(this.pnlActivityParticipants);
            this.Controls.Add(this.pnlListOfActivities);
            this.Controls.Add(this.pnlDrinkSupplies);
            this.Controls.Add(this.pnlRegisterUser);
            this.Controls.Add(this.pnlRecoverPassword);
            this.Controls.Add(this.pnlLoginPanel);
            this.Controls.Add(this.pnlReport);
            this.Controls.Add(this.pnlTeachers);
            this.Controls.Add(this.pnlRooms);
            this.Controls.Add(this.pnlStudents);
            this.Controls.Add(this.pnlDashboard);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "SomerenUI";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "SomerenApp";
            this.Load += new System.EventHandler(this.SomerenUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgDashboard)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlDashboard.ResumeLayout(false);
            this.pnlDashboard.PerformLayout();
            this.pnlTeachers.ResumeLayout(false);
            this.pnlTeachers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roompictureBox)).EndInit();
            this.pnlRooms.ResumeLayout(false);
            this.pnlRooms.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.pnlDrinksCash.ResumeLayout(false);
            this.pnlDrinksCash.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlStudents.ResumeLayout(false);
            this.pnlStudents.PerformLayout();
            this.pnlDrinkSupplies.ResumeLayout(false);
            this.pnlDrinkSupplies.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.drinkSuppliesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.pnlReport.ResumeLayout(false);
            this.pnlReport.PerformLayout();
            this.pnlListOfActivities.ResumeLayout(false);
            this.pnlListOfActivities.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activityListOfActivitiesPictureBox)).EndInit();
            this.pnlActivityParticipants.ResumeLayout(false);
            this.pnlActivityParticipants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activityParticipantPictureBox)).EndInit();
            this.pnlActivitySupervisors.ResumeLayout(false);
            this.pnlActivitySupervisors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.activitySupervisorPictureBox)).EndInit();
            this.pnlRecoverPassword.ResumeLayout(false);
            this.pnlRecoverPassword.PerformLayout();
            this.pnlLoginPanel.ResumeLayout(false);
            this.pnlLoginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginPanelPictureBox)).EndInit();
            this.pnlRegisterUser.ResumeLayout(false);
            this.pnlRegisterUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.registerNewUserPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supervisorDaoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supervisorDaoBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supervisorServiceBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgDashboard;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel pnlDashboard;
        private System.Windows.Forms.Label lbl_Dashboard;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teachersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activitiesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomsToolStripMenuItem;

        private System.Windows.Forms.Panel pnlTeachers;
        private System.Windows.Forms.ListView listViewTeachers;
        private System.Windows.Forms.ColumnHeader teacherID;
        private System.Windows.Forms.ColumnHeader teacherName;
        private System.Windows.Forms.ColumnHeader roomID;
        private System.Windows.Forms.PictureBox roompictureBox;
        private System.Windows.Forms.Label lbl_Teachers;

        private System.Windows.Forms.Panel pnlRooms;
        private System.Windows.Forms.ListView listViewRooms;
        private System.Windows.Forms.ColumnHeader roomNumber;
        private System.Windows.Forms.ColumnHeader roomCapacity;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader roomType;
        private System.Windows.Forms.ColumnHeader RoomRoomID;
        private System.Windows.Forms.ToolStripMenuItem drinksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drinkSuppliesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cashRegisterToolStripMenuItem;
        private System.Windows.Forms.Panel pnlDrinksCash;
        private System.Windows.Forms.ListView listViewDrinkStudents;
        private System.Windows.Forms.ColumnHeader DrinkStudentID;
        private System.Windows.Forms.ColumnHeader DrinkStudentName;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lbl_CashRegister;
        private System.Windows.Forms.CheckedListBox checkedListBoxDrinks;

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lbl_Students;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewStudents;
        private System.Windows.Forms.ColumnHeader studentID;
        private System.Windows.Forms.ColumnHeader studentName;
        private System.Windows.Forms.ColumnHeader studentDOB;
        private System.Windows.Forms.Panel pnlStudents;
        private System.Windows.Forms.Label label2;

        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.Label lblTotalDrinksCash;
        private System.Windows.Forms.Label TotalDrinksCash;
        private System.Windows.Forms.Panel pnlDrinkSupplies;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.TextBox changeAmountTextBox;
        private System.Windows.Forms.Button updateAmountButton;
        private System.Windows.Forms.ListView listViewDrinkSupplies;
        private System.Windows.Forms.ColumnHeader DrinkName;
        private System.Windows.Forms.ColumnHeader DrinkAmountInStock;
        private System.Windows.Forms.PictureBox drinkSuppliesPictureBox;
        private System.Windows.Forms.Label drinkSuppliesLabel;

        private System.Windows.Forms.ColumnHeader DrinkSalesPrice;
        private System.Windows.Forms.ColumnHeader DrinkId;

        private System.Windows.Forms.Label newNameLabel;
        private System.Windows.Forms.TextBox changeNameTextBox;
        private System.Windows.Forms.Button changeNameButton;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.TextBox idTextBox;

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel pnlReport;
        private System.Windows.Forms.Label txtNumberOfCustomers;
        private System.Windows.Forms.Label txtTurnover;
        private System.Windows.Forms.Label txtNumberOfSales;
        private System.Windows.Forms.Label lbNumberOfCustomers;
        private System.Windows.Forms.Label lbTurnover;
        private System.Windows.Forms.Label lbNumberOfSales;
        private System.Windows.Forms.Button buttonGenerate;
        private System.Windows.Forms.MonthCalendar monthCalendarStartDate;
        private System.Windows.Forms.Label lblReport;
        private System.Windows.Forms.ToolStripMenuItem revenueReportToolStripMenuItem;
        private System.Windows.Forms.ListView listViewReport;

        private System.Windows.Forms.ToolStripMenuItem activitySupervisorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listOfActivitiesToolStripMenuItem;
        private System.Windows.Forms.Panel pnlListOfActivities;
        private System.Windows.Forms.ListView listViewListOfActivities;
        private System.Windows.Forms.ColumnHeader ListOfActivitiesActivityID;
        private System.Windows.Forms.ColumnHeader ListOfActivitiesActivityStartDateTime;
        private System.Windows.Forms.PictureBox activityListOfActivitiesPictureBox;
        private System.Windows.Forms.Label lblListOfActivities;

        private System.Windows.Forms.TextBox txtListActivityName;
        private System.Windows.Forms.Label lblListActivityStartDateTime;
        private System.Windows.Forms.Label lblListActivityName;
        private System.Windows.Forms.Label addActivity;
        private System.Windows.Forms.Label removeActivity;
        private System.Windows.Forms.TextBox txtListActivityID;
        private System.Windows.Forms.Label lblListActivityID;
        private System.Windows.Forms.Button btnListActivityRemove;
        private System.Windows.Forms.Button btnListActivityAdd;
        private System.Windows.Forms.DateTimePicker dateTimePickerListActivity;
        private System.Windows.Forms.ColumnHeader ListOfActivitiesActivityName;

        private System.Windows.Forms.Panel pnlActivityParticipants;
        private System.Windows.Forms.ListView listViewParticipants;
        private System.Windows.Forms.ColumnHeader activityParticipantID;
        private System.Windows.Forms.ColumnHeader activityParticipantsStudentID;
        private System.Windows.Forms.ColumnHeader activityParticipantsActivityID;
        private System.Windows.Forms.ColumnHeader activityParticipantName;
        private System.Windows.Forms.PictureBox activityParticipantPictureBox;
        private System.Windows.Forms.Label lbActivityParticipant;
        private System.Windows.Forms.ToolStripMenuItem activityParticipantsToolStripMenuItem;
        private System.Windows.Forms.ListView listViewParticipantsActivities;
        private System.Windows.Forms.ColumnHeader activityParticipantsActivitiesActivityID;
        private System.Windows.Forms.ColumnHeader activityParticipantsActivitiesActivityStartDate;
        private System.Windows.Forms.ColumnHeader activityParticipantsActivitiesActivityName;
        private System.Windows.Forms.Label lbActivitiesParticipantsSelectedActivity;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.Button buttonAddParticipant;
        private System.Windows.Forms.Label lblActivityParticipantsStudentID;
        private System.Windows.Forms.Label lblActivityParticipantsParticipantID;
        private System.Windows.Forms.TextBox txtAddStudentID;
        private System.Windows.Forms.TextBox txtAddParticipantID;
        private System.Windows.Forms.Label lbAddParticipants;
        private System.Windows.Forms.Button buttonRemoveParticipant;

        private System.Windows.Forms.BindingSource supervisorDaoBindingSource;
        private System.Windows.Forms.BindingSource supervisorDaoBindingSource1;
        private System.Windows.Forms.BindingSource supervisorServiceBindingSource;
        private System.Windows.Forms.Label changeActivity;
        private System.Windows.Forms.DateTimePicker dateTimePickerListActivityChange;
        private System.Windows.Forms.Label lblListActivityStartDateTimeChange;
        private System.Windows.Forms.TextBox txtListActivityIDChange;
        private System.Windows.Forms.Label lblListActivityIDChange;
        private System.Windows.Forms.TextBox txtListActivityNameChange;
        private System.Windows.Forms.Label lblListActivityNameChange;
        private System.Windows.Forms.Button btnListActivityChangeStartDateTime;
        private System.Windows.Forms.Button btnListActivityChangeName;
        private System.Windows.Forms.Label lblDeviderLine1;
        private System.Windows.Forms.Label lblDeviderLine2;
        private System.Windows.Forms.ColumnHeader ListOfActivitiesActivityEndDateTime;
        private System.Windows.Forms.DateTimePicker endDateTimePickerListActivity;
        private System.Windows.Forms.Label lblListActivityEndDateTime;
        private System.Windows.Forms.DateTimePicker endDateTimePickerListActivityChange;
        private System.Windows.Forms.Label lblListActivityEndDateTimeChange;
        private System.Windows.Forms.Button btnListActivityChangeEndDateTime;
      
        private System.Windows.Forms.Panel pnlActivitySupervisors;
        private System.Windows.Forms.Label activitySupervisorsHeaderLabel;
        private System.Windows.Forms.Label activitySupervisorsActivitiesHeaderLabel;
        private System.Windows.Forms.Label teacherIDLabel;
        private System.Windows.Forms.TextBox supervisorTeacherIdTextBox;
        private System.Windows.Forms.TextBox supervisorIdTextBox;
        private System.Windows.Forms.Label addNewSupervisorLabel;
        private System.Windows.Forms.Label supervisorIdLabel;
        private System.Windows.Forms.Button supervisorDeleteButton;
        private System.Windows.Forms.Button addSupervisorButton;
        private System.Windows.Forms.ListView selectedActivitySupervisorsListView;
        private System.Windows.Forms.ColumnHeader activitySupervisorsSupervisorId;
        private System.Windows.Forms.ColumnHeader activitySupervisorsTeacherId;
        private System.Windows.Forms.ColumnHeader activitySupervisorsSelectedActivityId;
        private System.Windows.Forms.ColumnHeader activitySupervisorsSupervisorName;
        private System.Windows.Forms.ListView activitySupervisorsListView;
        private System.Windows.Forms.ColumnHeader activitySupervisorsActivityID;
        private System.Windows.Forms.ColumnHeader activitySupervisorsActivityEndDate;
        private System.Windows.Forms.ColumnHeader activitySupervisorActivityName;
        private System.Windows.Forms.PictureBox activitySupervisorPictureBox;
        private System.Windows.Forms.Label activitySupervisorLabel;
        private System.Windows.Forms.ColumnHeader activitySupervisorActivityStartDate;
        private System.Windows.Forms.ColumnHeader activityParticipantsActivitiesActivityEndDate;
        
        private System.Windows.Forms.Panel pnlRecoverPassword;
        private System.Windows.Forms.TextBox txtRecoverPasswordAnswer;
        private System.Windows.Forms.TextBox txtRecoverPasswordUsername;
        private System.Windows.Forms.Label lblRecoverPasswordSecretQuestion;
        private System.Windows.Forms.Label lblRecoverPasswordUsername;
        private System.Windows.Forms.ListView listViewRecoverPassword;
        private System.Windows.Forms.Label lblRecoverPassword;
        private System.Windows.Forms.Button buttonRecoverPasswordGetSecretQuestion;
        private System.Windows.Forms.Button buttonRecoverPasswordSetNewPassword;
        private System.Windows.Forms.TextBox txtRecoverPasswordNewPassword;
        private System.Windows.Forms.Label lblRecoverPasswordNewPassword;
        private System.Windows.Forms.Button buttonRecoverPasswordCheckAnswer;
        private System.Windows.Forms.Label lblRecoverPasswordResetMessage;
        private System.Windows.Forms.Button buttonRecoverPasswordReset;
        private System.Windows.Forms.Panel pnlLoginPanel;
        private System.Windows.Forms.PictureBox loginPanelPictureBox;
        private System.Windows.Forms.Label loginPanelLabel;
        private System.Windows.Forms.TextBox txtPasswordLoginPanel;
        private System.Windows.Forms.TextBox txtUsernameLoginPanel;
        private System.Windows.Forms.Label passwordLoginPanel;
        private System.Windows.Forms.Label usernameLoginPanel;
        private System.Windows.Forms.Button btnLoginPanel;

        private System.Windows.Forms.Button btnRecoverPasswordLoginPanel;
        private System.Windows.Forms.Panel pnlRegisterUser;
        private System.Windows.Forms.Label licenceKeyLabel;
        private System.Windows.Forms.TextBox licenceKeyTextBox;
        private System.Windows.Forms.Button registerButton;
        private System.Windows.Forms.TextBox passwordRegisterTextBox;
        private System.Windows.Forms.TextBox usernameRegisterTextBox;
        private System.Windows.Forms.Label passwordRegisterLabel;
        private System.Windows.Forms.Label usernameRegisterLabel;
        private System.Windows.Forms.PictureBox registerNewUserPictureBox;
        private System.Windows.Forms.Label registerUserLabel;
        private System.Windows.Forms.LinkLabel ToLoginFormLinkLabel;
        private System.Windows.Forms.TextBox secretAnswerTextBox;
        private System.Windows.Forms.TextBox secretQuestionTextBox;
        private System.Windows.Forms.Label secretAnswerLabel;
        private System.Windows.Forms.Label secretQuestionLabel;
        private System.Windows.Forms.Button buttonRegisterUser;
        private System.Windows.Forms.LinkLabel linkLabelBackToLogin;
    }
}

