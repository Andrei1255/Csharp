using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class SomerenUI : Form
    {
        public User currentUser;

        public SomerenUI()
        {
            InitializeComponent();
        }

        private void SomerenUI_Load(object sender, EventArgs e)
        {
            showPanel("Login");

            ColumnHeader roomColumn = new ColumnHeader();
            roomColumn.Text = "Room";
            roomColumn.Width = 40;
            listViewStudents.Columns.Add(roomColumn);

            ColumnHeader internationalColumn = new ColumnHeader();
            internationalColumn.Text = "International";
            internationalColumn.Width = 70;
            listViewStudents.Columns.Add(internationalColumn);

            monthCalendarStartDate.MaxDate = DateTime.Now;
        }

        private void showPanel(string panelName)
        {

            if (panelName == "Dashboard")
            {
                // hide all other panels
                HideAll();

                // show dashboard
                pnlDashboard.Show();
                imgDashboard.Show();
            }
            else if (panelName == "Students")
            {
                // hide all other panels
                HideAll();

                // show students
                pnlStudents.Show();

                try
                {
                    // fill the students listview within the students panel with a list of students
                    StudentService studService = new StudentService(); ;
                    List<Student> studentList = studService.GetStudents();

                    // clear the listview before filling it again
                    listViewStudents.Items.Clear();

                    foreach (Student s in studentList)
                    {
                        ListViewItem li = new ListViewItem(Convert.ToString(s.Number));
                        li.SubItems.Add(s.Name);
                        li.SubItems.Add(String.Format("{0:00}.{1:00}.{2}", s.BirthDate.Day, s.BirthDate.Month, s.BirthDate.Year));
                        li.SubItems.Add(Convert.ToString(s.Room));
                        li.SubItems.Add(s.International == 0 ? "No" : "Yes");
                        listViewStudents.Items.Add(li);
                    }
                    listViewStudents.View = View.Details;
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the students: " + e.Message);
                }
            }
            else if (panelName == "Teachers")
            {
                // hide all other panels
                HideAll();


                // show teachers
                pnlTeachers.Show();

                try
                {
                    // fill the Teachers listview within the Teachers panel with a list of teachers
                    TeacherService teacherService = new TeacherService();
                    List<Teacher> teacherList = teacherService.GetTeachers();

                    // clear the listview before filling it again
                    listViewTeachers.Items.Clear();

                    foreach (Teacher t in teacherList)
                    {
                        ListViewItem li = new ListViewItem(Convert.ToString(t.Id));
                        li.SubItems.Add(Convert.ToString(t.Name));
                        li.SubItems.Add(Convert.ToString(t.RoomId));
                        listViewTeachers.Items.Add(li);
                    }
                    listViewTeachers.View = View.Details;
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the teachers: " + e.Message);
                }
            }
            else if (panelName == "Rooms")
            {
                // hide all other panels
                HideAll();


                // show rooms
                pnlRooms.Show();

                try
                {
                    // fill the rooms listview within the students panel with a list of rooms
                    RoomService roomService = new RoomService();
                    List<Room> roomList = roomService.GetRooms();

                    // clear the listview before filling it again
                    listViewRooms.Items.Clear();

                    foreach (Room r in roomList)
                    {
                        ListViewItem li = new ListViewItem(r.Id.ToString());
                        li.SubItems.Add(r.Number.ToString());
                        li.SubItems.Add(r.Capacity.ToString());
                        if (r.Type)
                        {
                            li.SubItems.Add("Teachers");
                        }
                        else
                        {
                            li.SubItems.Add("Students");
                        }
                        listViewRooms.Items.Add(li);
                    }
                    listViewRooms.View = View.Details;
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the rooms: " + e.Message);
                }
                // show rooms
                pnlRooms.Show();
            }
            else if (panelName == "DrinksCash")
            {
                // hide all other panels
                HideAll();


                // show bar service
                pnlDrinksCash.Show();

                try
                {
                    // fill the Drinks listview within the Drinks panel with a list of drinks
                    DrinkService drinkService = new DrinkService();
                    List<Drink> drinkList = drinkService.GetDrinks();

                    // clear the listview before filling it again
                    listViewDrinkStudents.Items.Clear();
                    checkedListBoxDrinks.Items.Clear();

                    foreach (Drink d in drinkList)
                    {
                        ListViewItem li = new ListViewItem(d.DrinkId.ToString());
                        li.SubItems.Add(d.DrinkName);
                        li.SubItems.Add(d.DrinkPrice.ToString());
                        li.SubItems.Add(d.Amount.ToString());

                        listViewDrinkStudents.Items.Add(li);
                    }
                    listViewDrinkStudents.View = View.Details;

                    if(currentUser.User_AdminStatus != "admin")
                    {
                        btnBuy.Enabled = false;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the drinks: " + e.Message);
                }
            }
            else if (panelName == "Drink Supplies")
            {
                // hide all other panels
                HideAll();

                // show bar service
                pnlDrinkSupplies.Show();

                try
                {
                    // fill the DrinkSupplies listview within the Drink Supplies panel with a list of drinks
                    DrinkService drinkService = new DrinkService();
                    List<Drink> drinkList = drinkService.GetDrinksInStock();

                    // clear the listview before filling it again
                    listViewDrinkSupplies.Items.Clear();

                    foreach (Drink d in drinkList)
                    {
                        ListViewItem li = new ListViewItem(d.DrinkId.ToString());
                        li.SubItems.Add(d.DrinkName);
                        li.SubItems.Add(d.Amount.ToString());
                        li.SubItems.Add(d.DrinkPrice.ToString());

                        listViewDrinkSupplies.Items.Add(li);
                    }
                    listViewDrinkSupplies.View = View.Details;

                    if (currentUser.User_AdminStatus != "admin")
                    {
                        changeNameButton.Enabled = false;
                        updateAmountButton.Enabled = false;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the drinks: " + e.Message);
                }
            }

            else if (panelName == "Report")
            {
                // hide all other panels
                HideAll();

                // show bar service
                pnlReport.Show();
            }
            else if (panelName == "Activity Supervisors")
            {
                // hide all other panels
                HideAll();


                // show supervisors
                pnlActivitySupervisors.Show();

                try
                {
                    // fill the Activity List listview
                    ActivityService activityService = new ActivityService();
                    List<Activity> activityList = activityService.GetActivities();

                    // clear the listviews before filling it again
                    activitySupervisorsListView.Items.Clear();

                    foreach (Activity a in activityList)
                    {
                        ListViewItem li = new ListViewItem(Convert.ToString(a.ActivityId));

                        li.SubItems.Add(Convert.ToString(a.ActivityStartDateTime));
                        li.SubItems.Add(Convert.ToString(a.ActivityEndDateTime));
                        li.SubItems.Add(a.ActivityName);
                        activitySupervisorsListView.Items.Add(li);
                    }

                    activitySupervisorsListView.View = View.Details;

                    activitySupervisorsListView.Activation = ItemActivation.OneClick;

                    if (currentUser.User_AdminStatus != "admin")
                    {
                        addSupervisorButton.Enabled = false;
                        supervisorDeleteButton.Enabled = false;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the activities list: " + e.Message);
                }
            }
            else if (panelName == "List of Activities")
            {
                // hide all other panels
                HideAll();

                // show list of activities
                pnlListOfActivities.Show();

                try
                {
                    // fill the Activity List listview
                    ActivityService activityService = new ActivityService();
                    List<Activity> activityList = activityService.GetActivities();

                    // clear the listview before filling it again
                    listViewListOfActivities.Items.Clear();

                    foreach (Activity a in activityList)
                    {
                        ListViewItem li = new ListViewItem(Convert.ToString(a.ActivityId));
                        li.SubItems.Add(Convert.ToString(a.ActivityStartDateTime));
                        li.SubItems.Add(Convert.ToString(a.ActivityEndDateTime));
                        li.SubItems.Add(Convert.ToString(a.ActivityName));
                        listViewListOfActivities.Items.Add(li);
                    }
                    listViewListOfActivities.View = View.Details;

                    if (currentUser.User_AdminStatus != "admin")
                    {
                        btnListActivityAdd.Enabled = false;
                        btnListActivityRemove.Enabled = false;
                        btnListActivityChangeName.Enabled = false;
                        btnListActivityChangeStartDateTime.Enabled = false;
                        btnListActivityChangeEndDateTime.Enabled = false;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the activities list: " + e.Message);
                }
            }

            else if (panelName == "Activity Participants")
            {
                // hide all other panels
                HideAll();


                // show supervisors
                pnlActivityParticipants.Show();

                try
                {
                    ActivityService activityService = new ActivityService();
                    List<Activity> activityList = activityService.GetActivities();

                    // clear the listview before filling it again
                    listViewParticipantsActivities.Items.Clear();

                    foreach (Activity a in activityList)
                    {
                        ListViewItem li = new ListViewItem(Convert.ToString(a.ActivityId));
                        li.SubItems.Add(Convert.ToString(a.ActivityStartDateTime));
                        li.SubItems.Add(Convert.ToString(a.ActivityEndDateTime));
                        li.SubItems.Add(Convert.ToString(a.ActivityName));
                        listViewParticipantsActivities.Items.Add(li);
                    }
                    listViewParticipantsActivities.View = View.Details;

                    listViewParticipantsActivities.Activation = ItemActivation.TwoClick;

                    if (currentUser.User_AdminStatus != "admin")
                    {
                        buttonAddParticipant.Enabled = false;
                        buttonRemoveParticipant.Enabled = false;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the participants: " + e.Message);
                }
            }
            else if (panelName == "Login")
            {
                HideAll();

                pnlLoginPanel.Show();
            }

            else if (panelName == "Recover")
            {
                HideAll();

                pnlRecoverPassword.Show();
            }

            else if (panelName == "Register User")
            {
                // hide all other panels
                HideAll();

                pnlRegisterUser.Show();

            }
        }


        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dashboardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void imgDashboard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("What happens in Someren, stays in Someren!");
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Students");
        }

        private void TeachersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Teachers");
        }

        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Rooms");
        }

        private void DrinkToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cashRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // hide all other panels
            HideAll();

            // show cash register
            showPanel("DrinksCash");

            // fill the rooms listview within the drinks panel with a list of drinks
            DrinkService drinkService = new DrinkService();
            List<Drink> drinkList = drinkService.GetDrinks();

            // clear the listview before filling it again
            listViewDrinkStudents.Items.Clear();

            StudentService studentService = new StudentService();
            List<Student> students = studentService.GetStudents();

            foreach (Student s in students)
            {
                ListViewItem li = new ListViewItem(s.Number.ToString());
                li.SubItems.Add(s.Name);

                listViewDrinkStudents.Items.Add(li);
            }
            listViewDrinkStudents.View = View.Details;

            foreach (Drink d in drinkList)
            {
                checkedListBoxDrinks.Items.Add(d);
            }
        }

        private void drinksSuppliesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Drink Supplies");
        }

        private decimal PriceOfDrinksSelected()
        {
            decimal totalPrice = 0;
            foreach (Drink d in checkedListBoxDrinks.CheckedItems)
            {
                totalPrice += d.DrinkPrice;
            }
            return totalPrice;
        }

        private void checkedListBoxDrinks_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblTotalDrinksCash.Text = $"{PriceOfDrinksSelected():0.00}";
        }

        private void HideAll()
        {
            foreach (Control c in this.Controls)
            {
                if (c is Panel)
                {
                    c.Visible = false;
                }
            }
        }


        private void btnBuy_Click(object sender, EventArgs e)
        {
            int studentId = 0;
            int drinkId = 0;
            foreach (ListViewItem item in listViewDrinkStudents.Items)
            {
                if (item.Selected)
                {
                    studentId = item.Index + 1;
                    foreach (Drink d in checkedListBoxDrinks.CheckedItems)
                    {
                        drinkId = d.DrinkId;
                        OrderService orderService = new OrderService(studentId, drinkId);
                    }
                }
            }
            for (int i = 0; i < listViewDrinkStudents.Items.Count; i++)
            {
                listViewDrinkStudents.Items[i].Selected = false;
            }
            foreach (int i in checkedListBoxDrinks.CheckedIndices)
            {
                checkedListBoxDrinks.SetItemCheckState(i, CheckState.Unchecked);
            }
            lblTotalDrinksCash.Text = "0.00";
        }

        private void revenueReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Report");
        }

        private void buttonGenerate_Click(object sender, EventArgs e)
        {
            StudentService studentService = new StudentService();
            DrinkService drinkService = new DrinkService();

            int customersCount = studentService.GetStudentsCountThatPurchasedDrink(monthCalendarStartDate.SelectionRange.Start, monthCalendarStartDate.SelectionRange.End);
            int soldDrinksCount = drinkService.GetSoldDrinksCount(monthCalendarStartDate.SelectionRange.Start, monthCalendarStartDate.SelectionRange.End);
            double soldDrinksSum = drinkService.GetSoldDrinksPrice(monthCalendarStartDate.SelectionRange.Start, monthCalendarStartDate.SelectionRange.End);

            txtNumberOfCustomers.Text = customersCount.ToString();
            txtNumberOfSales.Text = soldDrinksCount.ToString();
            txtTurnover.Text = soldDrinksSum.ToString("0.00");
        }


        private void changeNameButton_Click(object sender, EventArgs e)
        {
            DrinkService drinkService = new DrinkService();
            Drink drink = new Drink();
            drink.DrinkName = changeNameTextBox.Text;
            drink.DrinkId = int.Parse(idTextBox.Text);
            drinkService.UpdateDrinkName(drink);
            showPanel("Drink Supplies");
        }

        private void updateAmountButton_Click(object sender, EventArgs e)
        {
            DrinkService drinkService = new DrinkService();
            Drink drink = new Drink();
            drink.Amount = int.Parse(changeAmountTextBox.Text);
            drink.DrinkId = int.Parse(idTextBox.Text);
            drinkService.UpdateDrinkAmount(drink);
            showPanel("Drink Supplies");
        }

        private void activitySupervisorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Activity Supervisors");
        }

        private void listOfActivitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("List of Activities");
        }


        private void btnListActivityAdd_Click(object sender, EventArgs e)
        {
            bool exists = false;
            foreach (ListViewItem l in listViewListOfActivities.Items)
            {
                if (l.SubItems[2].Text == txtListActivityName.Text)
                {
                    MessageBox.Show("Activity name already exists!");
                    exists = true;
                }
            }
            if (exists == false)
            {
                ActivityService activityService = new ActivityService();
                Activity activity = new Activity();
                activity.ActivityStartDateTime = DateTime.Parse(dateTimePickerListActivity.Value.ToString());
                activity.ActivityEndDateTime = DateTime.Parse(endDateTimePickerListActivity.Value.ToString());
                activity.ActivityName = txtListActivityName.Text;
                activityService.AddActivity(activity);
                showPanel("List of Activities");
            }
        }

        private void activityParticipantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Activity Participants");
        }

        private void listViewParticipantsActivities_ItemActivate(object sender, EventArgs e)
        {
            // fill the Activity Supervisors listview within the Activity Supervisors panel with a list of Supervisors
            ParticipantService participantService = new ParticipantService();

            int selectedActivityID = 0;

            foreach (ListViewItem li in listViewParticipantsActivities.SelectedItems)
                selectedActivityID = int.Parse(li.Text);

            List<Participant> participantsList = participantService.GetParticipants(selectedActivityID);

            // clear the listview before filling it again
            listViewParticipants.Items.Clear();

            foreach (Participant s in participantsList)
            {
                ListViewItem li = new ListViewItem(Convert.ToString(s.ParticipantId));
                li.SubItems.Add(Convert.ToString(s.StudentId));
                li.SubItems.Add(Convert.ToString(s.ActivityId));
                li.SubItems.Add(s.ParticipantName);
                listViewParticipants.Items.Add(li);
            }
            listViewParticipants.View = View.Details;
        }

        private void buttonAddParticipant_Click(object sender, EventArgs e)
        {
            ParticipantService participantService = new ParticipantService();

            int selectedActivityID = 0;

            foreach (ListViewItem li in listViewParticipantsActivities.SelectedItems)
                selectedActivityID = int.Parse(li.Text);

            participantService.AddParticipant(int.Parse(txtAddParticipantID.Text), int.Parse(txtAddStudentID.Text), selectedActivityID);

            List<Participant> participantsList = participantService.GetParticipants(selectedActivityID);

            // clear the listview before filling it again
            listViewParticipants.Items.Clear();

            foreach (Participant s in participantsList)
            {
                ListViewItem li = new ListViewItem(Convert.ToString(s.ParticipantId));
                li.SubItems.Add(Convert.ToString(s.StudentId));
                li.SubItems.Add(Convert.ToString(s.ActivityId));
                li.SubItems.Add(s.ParticipantName);
                listViewParticipants.Items.Add(li);
            }
            listViewParticipants.View = View.Details;

            listViewParticipants.Activation = ItemActivation.TwoClick;
        }

        private void buttonRemoveParticipant_Click(object sender, EventArgs e)
        {
            int selectedParticipantID = 0;

            foreach (ListViewItem li in listViewParticipants.SelectedItems)
                selectedParticipantID = int.Parse(li.Text);

            ParticipantService participantService = new ParticipantService();

            DialogResult result = MessageBox.Show($"Are you sure you want to delete participant with id {selectedParticipantID} ?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result.Equals(DialogResult.OK))
            {
                participantService.RemoveParticipant(selectedParticipantID);

                int selectedActivityID = 0;

                foreach (ListViewItem li in listViewParticipantsActivities.SelectedItems)
                    selectedActivityID = int.Parse(li.Text);

                List<Participant> participantsList = participantService.GetParticipants(selectedActivityID);

                // clear the listview before filling it again
                listViewParticipants.Items.Clear();

                foreach (Participant s in participantsList)
                {
                    ListViewItem li = new ListViewItem(Convert.ToString(s.ParticipantId));
                    li.SubItems.Add(Convert.ToString(s.StudentId));
                    li.SubItems.Add(Convert.ToString(s.ActivityId));
                    li.SubItems.Add(s.ParticipantName);
                    listViewParticipants.Items.Add(li);
                }
                listViewParticipants.View = View.Details;

                listViewParticipants.Activation = ItemActivation.TwoClick;
            }
        }

        private void btnListActivityRemove_Click(object sender, EventArgs e)
        {
            DialogResult d;
            d = MessageBox.Show("Are you sure that you wish to remove this activity?", "Are you sure???", MessageBoxButtons.YesNo);
            if (d == DialogResult.Yes)
            {
                ActivityService activityService = new ActivityService();
                Activity activity = new Activity();
                activity.ActivityId = int.Parse(txtListActivityID.Text);
                activityService.RemoveActivity(activity);
                showPanel("List of Activities");
            }
        }

        private void btnListActivityChangeName_Click(object sender, EventArgs e)
        {
            ActivityService activityService = new ActivityService();
            Activity activity = new Activity();
            activity.ActivityId = int.Parse(txtListActivityIDChange.Text);
            activity.ActivityName = txtListActivityNameChange.Text;
            activityService.ChangeActivityName(activity);
            showPanel("List of Activities");
        }

        private void btnListActivityChangeDateTime_Click(object sender, EventArgs e)
        {
            ActivityService activityService = new ActivityService();
            Activity activity = new Activity();
            activity.ActivityId = int.Parse(txtListActivityIDChange.Text);
            activity.ActivityStartDateTime = DateTime.Parse(dateTimePickerListActivityChange.Value.ToString());
            activityService.ChangeActivityStartDateTime(activity);
            showPanel("List of Activities");
        }

        private void btnListActivityChangeEndDateTime_Click(object sender, EventArgs e)
        {
            ActivityService activityService = new ActivityService();
            Activity activity = new Activity();
            activity.ActivityId = int.Parse(txtListActivityIDChange.Text);
            activity.ActivityEndDateTime = DateTime.Parse(endDateTimePickerListActivityChange.Value.ToString());
            activityService.ChangeActivityEndDateTime(activity);
            showPanel("List of Activities");
        }

        private void addSupervisorButton_Click(object sender, EventArgs e)
        {
            Supervisor supervisor = new Supervisor();

            foreach (ListViewItem li in activitySupervisorsListView.SelectedItems)
            {
                supervisor.ActivityId = int.Parse(li.Text);
            }

            supervisor.SupervisorId = int.Parse(supervisorIdTextBox.Text);
            supervisor.TeacherId = int.Parse(supervisorTeacherIdTextBox.Text);

            SupervisorService supervisorService = new SupervisorService();
            supervisorService.AddSupervisor(supervisor);
            List<Supervisor> supervisorList = supervisorService.GetSupervisorsInActivity(supervisor);

            selectedActivitySupervisorsListView.Items.Clear();

            foreach (Supervisor s in supervisorList)
            {
                ListViewItem li = new ListViewItem(Convert.ToString(s.SupervisorId));
                li.SubItems.Add(Convert.ToString(s.TeacherId));
                li.SubItems.Add(Convert.ToString(s.ActivityId));
                li.SubItems.Add(s.SupervisorName);
                selectedActivitySupervisorsListView.Items.Add(li);
            }
            selectedActivitySupervisorsListView.View = View.Details;

            selectedActivitySupervisorsListView.Activation = ItemActivation.OneClick;
        }

        private void supervisorDeleteButton_Click(object sender, EventArgs e)
        {
            Supervisor supervisor = new Supervisor();

            foreach (ListViewItem li in selectedActivitySupervisorsListView.SelectedItems)
            {
                supervisor.SupervisorId = int.Parse(li.Text);
            }

            SupervisorService supervisorService = new SupervisorService();

            DialogResult result = MessageBox.Show($"Are you sure that you wish to remove this supervisor?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                supervisorService.DeleteSupervisor(supervisor);

                int selectedActivityId = 0;

                foreach (ListViewItem li in activitySupervisorsListView.SelectedItems)
                {
                    selectedActivityId = int.Parse(li.Text);
                }

                List<Supervisor> supervisorList = supervisorService.GetSupervisorsInActivity(supervisor);

                selectedActivitySupervisorsListView.Items.Clear();

                foreach (Supervisor s in supervisorList)
                {
                    ListViewItem li = new ListViewItem(Convert.ToString(s.SupervisorId));
                    li.SubItems.Add(Convert.ToString(s.TeacherId));
                    li.SubItems.Add(Convert.ToString(s.ActivityId));
                    li.SubItems.Add(s.SupervisorName);
                    selectedActivitySupervisorsListView.Items.Add(li);
                }
            }
            selectedActivitySupervisorsListView.View = View.Details;

            selectedActivitySupervisorsListView.Activation = ItemActivation.OneClick;
        }

        private void activitySupervisorsListView_ItemActivate(object sender, EventArgs e)
        {
            Supervisor supervisor = new Supervisor();

            foreach (ListViewItem li in activitySupervisorsListView.SelectedItems)
            {
                supervisor.ActivityId = int.Parse(li.Text);
            }

            // fill the selectedActivitySupervisors listview within the Activity Supervisors panel with a list of Supervisors that where added to the selected activity
            SupervisorService supervisorService = new SupervisorService();
            List<Supervisor> supervisorList = supervisorService.GetSupervisorsInActivity(supervisor);

            selectedActivitySupervisorsListView.Items.Clear();

            foreach (Supervisor s in supervisorList)
            {
                ListViewItem li = new ListViewItem(Convert.ToString(s.SupervisorId));
                li.SubItems.Add(Convert.ToString(s.TeacherId));
                li.SubItems.Add(Convert.ToString(s.ActivityId));
                li.SubItems.Add(s.SupervisorName);
                selectedActivitySupervisorsListView.Items.Add(li);
            }
            selectedActivitySupervisorsListView.View = View.Details;
        }

        private void buttonRecoverPasswordGetSecretQuestion_Click(object sender, EventArgs e)
        {
            UserService userService = new UserService();

            string userName = txtRecoverPasswordUsername.Text;

            string secretQuestion = userService.GetSecretQuestion(userName);

            lblRecoverPasswordSecretQuestion.Text = secretQuestion;

            string errorMessageText = String.Format("No user found with name {0} !", userName);

            if (secretQuestion != errorMessageText)
            {
                txtRecoverPasswordAnswer.Visible = true;
                buttonRecoverPasswordCheckAnswer.Visible = true;
                txtRecoverPasswordUsername.Enabled = false;
                buttonRecoverPasswordGetSecretQuestion.Enabled = false;
            }
        }

        private void buttonRecoverPasswordCheckAnswer_Click(object sender, EventArgs e)
        {
            UserService userService = new UserService();

            string userName = txtRecoverPasswordUsername.Text;

            string secretAnswer = txtRecoverPasswordAnswer.Text;

            bool checkAnswer = userService.CheckSecretAnswer(userName, secretAnswer);

            if (checkAnswer == true)
            {
                lblRecoverPasswordNewPassword.Text = "Enter the new password:";
                txtRecoverPasswordNewPassword.Visible = true;
                buttonRecoverPasswordSetNewPassword.Visible = true;
                txtRecoverPasswordAnswer.Enabled = false;
                buttonRecoverPasswordCheckAnswer.Enabled = false;
            }

            else
            {
                lblRecoverPasswordNewPassword.Text = "Incorrect answer !";
            }
        }

        private void buttonRecoverPasswordSetNewPassword_Click(object sender, EventArgs e)
        {
            UserService userService = new UserService();

            string userName = txtRecoverPasswordUsername.Text;

            string newPassword = txtRecoverPasswordNewPassword.Text;

            userService.ChangePassword(userName, newPassword);

            lblRecoverPasswordResetMessage.Text = "Password successfully changed !";
        }

        private void buttonRecoverPasswordReset_Click(object sender, EventArgs e)
        {
            txtRecoverPasswordUsername.Enabled = true;
            txtRecoverPasswordUsername.Text = "";
            txtRecoverPasswordAnswer.Visible = false;
            txtRecoverPasswordAnswer.Text = "";
            txtRecoverPasswordAnswer.Enabled = true;
            txtRecoverPasswordNewPassword.Text = "";
            txtRecoverPasswordNewPassword.Visible = false;

            buttonRecoverPasswordGetSecretQuestion.Enabled = true;
            buttonRecoverPasswordCheckAnswer.Visible = false;
            buttonRecoverPasswordSetNewPassword.Visible = false;
            buttonRecoverPasswordCheckAnswer.Enabled = true;
            buttonRecoverPasswordGetSecretQuestion.Enabled = true;

            lblRecoverPasswordSecretQuestion.Text = "";
            lblRecoverPasswordNewPassword.Text = "";
            lblRecoverPasswordResetMessage.Text = "";
        }

        private void btnLoginPanel_Click(object sender, EventArgs e)
        {

            UserService userService = new UserService();

            string username = txtUsernameLoginPanel.Text;
            string password = txtPasswordLoginPanel.Text;

            bool loginSucceeded = userService.ComparePassword(username, password);

            if (loginSucceeded == true)
            {
                pnlLoginPanel.Hide();
                pnlDashboard.Show();

                currentUser = userService.GetUser(username);
            }
            else
            {
                MessageBox.Show(String.Format("Wrong login!"));
            }
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            User user;

            UserService userService = new UserService();

            if (userService.GetUser(usernameRegisterTextBox.Text.Trim()) != null)
            {
                MessageBox.Show("This username already exists!");
            }
            else
            {
                user = new User();

                user.User_Name = usernameRegisterTextBox.Text.Trim();
                user.User_Password = passwordRegisterTextBox.Text.Trim();
                user.User_SecretQuestion = secretQuestionTextBox.Text.Trim();
                user.User_SecretAnswer = secretAnswerTextBox.Text.Trim();
                user.User_AdminStatus = "user";

                if (userService.CompareLicenceKey(licenceKeyTextBox.Text.Trim()))
                {
                    userService.AddUser(user);
                }
                else
                {
                    MessageBox.Show("Incorrect licence key!");
                }
            }
        }

        private void ToLoginFormLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showPanel("Login");
        }

        private void btnRecoverPasswordLoginPanel_Click(object sender, EventArgs e)
        {
            showPanel("Recover");
        }

        private void buttonRegisterUser_Click(object sender, EventArgs e)
        {
            showPanel("Register User");
        }

        private void linkLabelBackToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showPanel("Login");
        }
    }
}
