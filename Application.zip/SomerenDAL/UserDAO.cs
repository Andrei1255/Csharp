﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class UserDAO : BaseDao
    {
        public List<User> GetUsers()
        {
            //change query
            string query = String.Format("SELECT User_ID, User_Name, User_Password, User_SecretQuestion, User_SecretAnswer, User_AdminStatus FROM Users");
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        public User GetUser(string userName)
        {
            //change query
            string query = String.Format("SELECT User_ID, User_Name, User_Password, User_SecretQuestion, User_SecretAnswer, User_AdminStatus FROM Users WHERE User_Name=@userName");
            SqlParameter[] sqlParameters = new SqlParameter[1]
            {
                new SqlParameter("@userName", userName)
            };

            DataTable dataTable = ExecuteSelectQuery(query, sqlParameters);

            if (dataTable.Rows.Count < 1)
                return null;

            DataRow dr = dataTable.Rows[0];

            User user = new User()
            {
                User_ID = (int)dr["User_ID"],
                User_Password = (string)dr["User_Password"],
                User_SecretQuestion = (string)dr["User_SecretQuestion"],
                User_SecretAnswer = (string)dr["User_SecretAnswer"],
                User_AdminStatus = (string)dr["User_AdminStatus"]
            };

            return user;
        }

        private List<User> ReadTables(DataTable dataTable)
        {
            List<User> users = new List<User>();

            foreach (DataRow dr in dataTable.Rows)
            {
                User user = new User()
                {
                    User_ID = (int)dr["User_ID"],
                    User_Password = (string)dr["User_Password"],
                    User_SecretQuestion = (string)dr["User_SecretQuestion"],
                    User_SecretAnswer = (string)dr["User_SecretAnswer"],
                    User_AdminStatus = (string)dr["User_AdminStatus"]
                };
                users.Add(user);
            }

            return users;
        }

        public string GetSecretQuestion(string userName)
        {
            //change query
            string query = String.Format("SELECT User_SecretQuestion FROM Users WHERE User_Name='{0}'", userName);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            //return (string)ExecuteSelectQuery(query, sqlParameters).Rows[0]["User_SecretQuestion"];

            DataTable dataTable = ExecuteSelectQuery(query, sqlParameters);

            if(dataTable.Rows.Count > 0)
            {
                return (string)dataTable.Rows[0]["User_SecretQuestion"];
            }

            else
            {
                return String.Format("No user found with name {0} !", userName);
            }
        }

        public string GetSecretAnswer(string userName)
        {
            //change query
            string query = String.Format("SELECT User_SecretAnswer FROM Users WHERE User_Name='{0}'", userName);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return (string)ExecuteSelectQuery(query, sqlParameters).Rows[0]["User_SecretAnswer"];
        }

        public void ChangePassword(string userName, string newPassword)
        {
            string query = String.Format("UPDATE Users SET User_Password='{0}' WHERE User_Name='{1}'", newPassword, userName);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }

        public void ChangePassword(int userID, string newPassword)
        {
            string query = String.Format("UPDATE Users SET User_Password='{0}' WHERE User_ID={1}", newPassword, userID);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }

        public bool CheckSecretAnswer(string userName, string answer)
        {
            string query = String.Format("SELECT User_Name FROM Users WHERE User_Name='{0}' AND User_SecretAnswer='{1}'", userName, answer);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            DataTable dataTable = ExecuteSelectQuery(query, sqlParameters);

            if (dataTable.Rows.Count > 0)
                return true;

            return false;
        }
        public string GetPassword(string userName)
        {
            string query = String.Format("SELECT User_Password FROM Users WHERE User_Name='{0}'", userName);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return (string)ExecuteSelectQuery(query, sqlParameters).Rows[0]["User_Password"];
        }

        public void AddUser(User user)
        {
            string query = "INSERT INTO Users(User_Name, User_Password, User_SecretQuestion, User_SecretAnswer, User_AdminStatus)" +
                $"VALUES(@userName, @userPassword, @secretQuestion, @secretAnswer, @adminStatus)";
            SqlParameter[] sqlParameters = new SqlParameter[5]
            {
                new SqlParameter("@userName", user.User_Name),
                new SqlParameter("@userPassword", user.User_Password),
                new SqlParameter("@secretQuestion", user.User_SecretQuestion),
                new SqlParameter("@secretAnswer", user.User_SecretAnswer),
                new SqlParameter("@adminStatus", user.User_AdminStatus)
            };
            ExecuteEditQuery(query, sqlParameters);
        }

        public bool CompareLicenceKey(string licenceKey)
        {
            if(licenceKey == "XsZAb - tgz3PsD - qYh69un - WQCEx")
            {
                return true;
            }

            return false;
        }
    }
}
