﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenDAL
{
    public class OrderDAO : BaseDao
    {
        public void MakeOrder(int studentId, int drinkId)
        {
            string query = $"INSERT INTO orders(Student_Id,Drink_Id)" +
                $"VALUES({studentId}, {drinkId})";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
