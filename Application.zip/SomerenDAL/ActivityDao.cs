﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class ActivityDao : BaseDao
    {
        public List<Activity> GetAllActivities()
        {
            string query = "SELECT Activity_Id, Activity_StartDateTime, Activity_EndDateTime, Activity_Name FROM Activity";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Activity> ReadTables(DataTable dataTable)
        {
            List<Activity> activities = new List<Activity>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Activity activity = new Activity()
                {
                    ActivityId = (int)dr["Activity_Id"],
                    ActivityStartDateTime = (DateTime)dr["Activity_StartDateTime"],
                    ActivityEndDateTime = (DateTime)dr["Activity_EndDateTime"],
                    ActivityName = (string)dr["Activity_Name"]
                };
                activities.Add(activity);
            }
            return activities;
        }
        public void AddActivity(Activity activity)
        {
            string query = $"INSERT INTO Activity(Activity_StartDateTime,Activity_EndDateTime,Activity_Name) VALUES(@activityStartDateTime, @activityEndDateTime, @activityName)";
            SqlParameter[] sqlParameters = new SqlParameter[3]
            {
                new SqlParameter("@activityStartDateTime", activity.ActivityStartDateTime.ToString("yyyy-MM-dd HH:mm:ss")),
                new SqlParameter("@activityEndDateTime", activity.ActivityEndDateTime.ToString("yyyy-MM-dd HH:mm:ss")),
                new SqlParameter("@activityName", activity.ActivityName)
            };

            ExecuteEditQuery(query, sqlParameters);
        }
        public void RemoveActivity(Activity activity)
        {
            string queryParticipants = $"DELETE FROM Participant WHERE Activity_Id=(@activityID)";
            SqlParameter[] sqlParametersParticipants = new SqlParameter[1]
            {
                new SqlParameter("@activityID", activity.ActivityId)
            };
            ExecuteEditQuery(queryParticipants, sqlParametersParticipants);

            string querySupervisors = $"DELETE FROM Supervisor WHERE Activity_Id=(@activityID)";
            SqlParameter[] sqlParametersSupervisors = new SqlParameter[1]
            {
                new SqlParameter("@activityID", activity.ActivityId)
            };
            ExecuteEditQuery(querySupervisors, sqlParametersSupervisors);

            string query = $"DELETE FROM Activity WHERE Activity_Id=(@activityID)";
            SqlParameter[] sqlParameters = new SqlParameter[1]
            {
                new SqlParameter("@activityID", activity.ActivityId)
            };
            ExecuteEditQuery(query, sqlParameters);
        }
        public void ChangeActivityName(Activity activity)
        {
            string query = $"UPDATE Activity SET Activity_Name=@ActivityName WHERE Activity_Id=@ActivityID";
            SqlParameter[] sqlParameters = new SqlParameter[2]
            {
                new SqlParameter("@ActivityName", activity.ActivityName),
                new SqlParameter("@activityID", activity.ActivityId)
            };

            ExecuteEditQuery(query, sqlParameters);
        }
        public void ChangeActivityStartDateTime(Activity activity)
        {
            string query = $"UPDATE Activity SET Activity_StartDateTime=@ActivityStartDateTime WHERE Activity_Id=@ActivityID";
            SqlParameter[] sqlParameters = new SqlParameter[2]
            {
                new SqlParameter("@ActivityStartDateTime", activity.ActivityStartDateTime),
                new SqlParameter("@activityID", activity.ActivityId)
            };

            ExecuteEditQuery(query, sqlParameters);
        }
        public void ChangeActivityEndDateTime(Activity activity)
        {
            string query = $"UPDATE Activity SET Activity_EndDateTime=@ActivityEndDateTime WHERE Activity_Id=@ActivityID";
            SqlParameter[] sqlParameters = new SqlParameter[2]
            {
                new SqlParameter("@ActivityEndDateTime", activity.ActivityEndDateTime),
                new SqlParameter("@activityID", activity.ActivityId)
            };

            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
