﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class SupervisorDao : BaseDao
    {

        public List<Supervisor> GetAllSupervisorsInActivity(Supervisor supervisor)
        {
            string query = $"SELECT Supervisor_Id, Supervisor.Teacher_Id, Activity_Id, Teacher.Teacher_Name FROM Supervisor JOIN Teacher ON Teacher.Teacher_Id = Supervisor.Teacher_Id WHERE Activity_Id = (@activityID) ORDER BY Activity_Id;";
            SqlParameter[] sqlParameters = new SqlParameter[1]
            {
                new SqlParameter("@activityID", supervisor.ActivityId)
            };
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Supervisor> ReadTables(DataTable dataTable)
        {
            List<Supervisor> supervisors = new List<Supervisor>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Supervisor supervisor = new Supervisor()
                {
                    SupervisorId = (int)dr["Supervisor_Id"],
                    TeacherId = (int)dr["Teacher_Id"],
                    ActivityId = (int)dr["Activity_Id"],
                    SupervisorName = (string)dr["Teacher_Name"]
                };
                supervisors.Add(supervisor);
            }
            return supervisors;
        }

        public void AddSupervisor(Supervisor supervisor)
        {
            string query = "INSERT INTO Supervisor(Supervisor_Id, Teacher_Id, Activity_Id)" +
                $"VALUES(@supervisorID, @teacherID, @activityID)";
            SqlParameter[] sqlParameters = new SqlParameter[3]
            {
                new SqlParameter("@supervisorID", supervisor.SupervisorId),
                new SqlParameter("@teacherID", supervisor.TeacherId),
                new SqlParameter("@activityID", supervisor.ActivityId)
            };
            ExecuteEditQuery(query, sqlParameters);
        }

        public void DeleteSupervisor(Supervisor supervisor)
        {
            string query = $"DELETE FROM Supervisor WHERE Supervisor_Id=(@supervisorID);";
            SqlParameter[] sqlParameters = new SqlParameter[1]
            {
                new SqlParameter("@supervisorID", supervisor.SupervisorId)
            };
            ExecuteEditQuery(query, sqlParameters);
        }
    }
}