﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class StudentDao : BaseDao
    {      
        public List<Student> GetAllStudents()
        {
            string query = "SELECT Student_Id, Room_Id, Student_Name, Student_Birthdate, Student_International FROM Student";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        public int GetStudentsCountThatPurchasedDrink(DateTime startDate, DateTime endDate)
        {
            string query = String.Format("SELECT COUNT(DISTINCT Student_Id), COUNT(DISTINCT Teacher_Id) FROM Drinks WHERE (Teacher_Id IS NOT NULL OR Student_Id IS NOT NULL) AND SoldDate>='{0}-{1:00}-{2:00}' AND SoldDate<='{3}-{4:00}-{5:00}'",
                startDate.Year, startDate.Month, startDate.Day,
                endDate.Year, endDate.Month, endDate.Day);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadCount(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Student> ReadTables(DataTable dataTable)
        {
            List<Student> students = new List<Student>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Student student = new Student()
                {
                    Number = (int)dr["Student_Id"],
                    Room = (int)dr["Room_Id"],
                    Name = (string)(dr["Student_Name"].ToString()),
                    International = (int)dr["Student_International"],
                    BirthDate = (DateTime)dr["Student_Birthdate"]
                };
                students.Add(student);
            }
            return students;
        }

        private int ReadCount(DataTable dataTable)
        {
            int count = 0;

            foreach (DataRow dr in dataTable.Rows)
            {
                count = (int)dr[0] + (int)dr[1];
            }

            return count;
        }
    }
}
