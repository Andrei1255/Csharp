﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class DrinkDao : BaseDao
    {
        public List<Drink> GetAllDrinks()
        {
            //change query
            string query = "SELECT * FROM Drinks";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        public int GetAllSoldDrinks(DateTime startDate, DateTime endDate)
        {
            string query = String.Format("SELECT COUNT(*) FROM Drinks WHERE (Student_Id IS NOT NULL OR Teacher_Id IS NOT NULL) AND SoldDate>='{0}-{1:00}-{2:00}' AND SoldDate<='{3}-{4:00}-{5:00}'",
                startDate.Year, startDate.Month, startDate.Day,
                endDate.Year, endDate.Month, endDate.Day);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadCount(ExecuteSelectQuery(query, sqlParameters));
        }

        public double GetAllSoldDrinksPrice(DateTime startDate, DateTime endDate)
        {
            string query = String.Format("SELECT SUM(Drink_Price) FROM Drinks WHERE (Student_Id IS NOT NULL OR Teacher_Id IS NOT NULL) AND SoldDate>='{0}-{1:00}-{2:00}' AND SoldDate<='{3}-{4:00}-{5:00}'",
                startDate.Year, startDate.Month, startDate.Day,
                endDate.Year, endDate.Month, endDate.Day);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadSum(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> drinks = new List<Drink>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    DrinkPrice = (decimal)dr["Drink_Price"],
                    DrinkId = (int)dr["Drink_Id"],
                    DrinkName = (string)dr["Drink_Name"],
                    Amount = (int)dr["Amount"]
                    //StudentId = (int)dr["Student_Id"],
                    //TeacherId = (int)dr["Teacher_Id"],
                };
                drinks.Add(drink);
            }
            return drinks;
        }


        private int ReadCount(DataTable dataTable)
        {
            int count = 0;

            foreach (DataRow dr in dataTable.Rows)
            {
                count = (int)dr[0];
            }

            return count;
        }

        private double ReadSum(DataTable dataTable)
        {
            double sum = 0;

            foreach (DataRow dr in dataTable.Rows)
            {
                if (dr[0].GetType() == typeof(DBNull))
                    sum = 0;
                else
                    sum = Convert.ToDouble(dr[0]);
            }

            return sum;
        }
        // This method selects all the drinks that have a stock amount greater than 1, 
        // of which the sales price is greater than 1 drinks token, sorted according to stock,
        // subsequently according to sales value and then according to number of drinks sold.
        public List<Drink> GetAllDrinksInStock()
        {
            string query = "SELECT Drink_Id, Drink_Name, Amount, Drink_Price FROM Drinks WHERE Amount > 0 AND Drink_Price > 1 ORDER BY Amount, Drink_Price";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        public void UpdateDrinkName(Drink drink)
        {
            string query = $"UPDATE Drinks SET Drink_Name=(@drinkName) WHERE Drink_Id = (@drinkID)";
            SqlParameter[] sqlParameters = new SqlParameter[2]
            {
                new SqlParameter("@drinkName", drink.DrinkName),
                new SqlParameter("@drinkID", drink.DrinkId)
            };
            ExecuteEditQuery(query, sqlParameters);
        }

        public void UpdateDrinkAmount(Drink drink)
        {
            string query = $"UPDATE Drinks SET Amount = (@drinkAmount) WHERE Drink_Id = (@drinkID) ;";
            SqlParameter[] sqlParameters = new SqlParameter[2]
            {
                new SqlParameter("@drinkAmount", drink.Amount),
                new SqlParameter("@drinkID", drink.DrinkId)
            };
            ExecuteEditQuery(query, sqlParameters);

        }
    }
}
