﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class ParticipantDao : BaseDao
    {
        public List<Participant> GetAllParticipants(int activityID)
        {
            string query = String.Format("SELECT Participant_Id, Activity_Id, Participant.Student_Id, Student.Student_Name FROM Participant INNER JOIN Student ON Student.Student_Id=Participant.Student_Id WHERE Activity_Id={0}", activityID);
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Participant> ReadTables(DataTable dataTable)
        {
            List<Participant> participants = new List<Participant>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Participant participant = new Participant()
                {
                    ParticipantId = (int)dr["Participant_Id"],
                    StudentId = (int)dr["Student_Id"],
                    ActivityId = (int)dr["Activity_Id"],
                    ParticipantName = (string)dr["Student_Name"]
                };
                participants.Add(participant);
            }
            return participants;
        }

        public void AddParticipant(int participantId, int studentId, int activityId)
        {
            string query = $"INSERT INTO Participant(Participant_Id, Student_Id, Activity_Id)" +
                $"VALUES({participantId}, {studentId}, {activityId})";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }

        public void RemoveParticipant(int participantId)
        {
            string query = $"DELETE FROM Participant WHERE Participant_Id={participantId}";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
    }
}
